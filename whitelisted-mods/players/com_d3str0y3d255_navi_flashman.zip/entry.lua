function package_init(package) 
    package:declare_package_id("com.d3str0y3d255.navi.flashman")
    package:set_speed(1.0)
	package:set_attack(1)
	package:set_charged_attack(10)
    package:set_special_description("It will be over in a flash")
	package:set_icon_texture(Engine.load_texture(_modpath.."pet.png"))
	package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."ow.animation")
    package:set_overworld_texture_path(_modpath.."ow.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
	package:set_mugshot_texture_path(_modpath.."mug.png")
	package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("Flashman")
	player:set_health(1000)
	player:set_element(Element.Elec)
    player:set_height(67.0)
	player:set_charge_position(1,-33)
    player:set_animation(_modpath.."flashman.animation")
    player:set_texture(Engine.load_texture(_modpath.."navi_flashman_atlas.og.png"), false)
    player:set_fully_charged_color(Color.new(72, 208, 176, 255))
    player.normal_attack_func = create_normal_attack
    player.charged_attack_func = create_charged_attack
	player.special_attack_func = summon_tower	
    player.towerspawned = false	
    player.tower_attack = false
    player.tower_attack_start = false	
	
	player.update_func = function()
	if player.towerspawned == true and Battle.Player.from(player).special_attack_func == summon_tower and Battle.Player.from(player).charged_attack_func == create_charged_attack then
    player.charged_attack_func = create_charged_attack2
	player.special_attack_func = create_special_attack	
	player:set_fully_charged_color(Color.new(240, 208, 80, 255))	
	elseif player.towerspawned == false and Battle.Player.from(player).special_attack_func == create_special_attack then
    player.charged_attack_func = create_charged_attack
	player.special_attack_func = summon_tower	
	player:set_fully_charged_color(Color.new(72, 208, 176, 255))
	elseif player.towerspawned == true and Battle.Player.from(player).special_attack_func == summon_tower and Battle.Player.from(player).charged_attack_func ~= create_charged_attack then
	player.special_attack_func = void
	elseif player.towerspawned == false and Battle.Player.from(player).special_attack_func == void then	
	player.special_attack_func = summon_tower		
	  end
   end
   
end

function create_normal_attack(player)
    return Battle.Buster.new(player, false, player:get_attack_level())
end

function create_charged_attack(player)
    local props = Battle.CardProperties:new()
    props.damage = (player:get_attack_level() * 10)
    return include("Chips/Elec/entry.lua").card_create_action(player, props)
end

function create_charged_attack2(player)
    local action = Battle.CardAction.new(player, "PLAYER_FLASH")
    player.tower_attack = true
    player.tower_attack_start = true	
    action.execute_func = function(self, player)

    end

    action.action_end_func = function(self)
			
            end

    player:card_action_event(action, ActionOrder.Immediate)
end

function create_special_attack(player)
    if Battle.Player.from(player).charged_attack_func == create_charged_attack then
		player:set_fully_charged_color(Color.new(240, 208, 80, 255))
        player.charged_attack_func = create_charged_attack2
	
    elseif Battle.Player.from(player).charged_attack_func == create_charged_attack2 then
	player:set_fully_charged_color(Color.new(72, 208, 176, 255))
        player.charged_attack_func = create_charged_attack
		
    end
end

function void(player)

end

function summon_tower(player)
    local action = Battle.CardAction.new(player, "PLAYER_SUMMON")

    local query = function(ent)
        if (Battle.Obstacle.from(ent) ~= nil and ent:get_name() ~= "Flash Tower") or Battle.Character.from(ent) ~= nil then
            return true
        end
    end

    local tower = Battle.Obstacle.new(player:get_team())

    action.execute_func = function(self)
	    Engine.play_audio(Engine.load_audio(_folderpath .. "Chips/Tower/sfx.ogg"), AudioPriority.High)
		
        local animation = tower:get_animation()
        animation:load(_modpath.."flashman.animation")
        animation:set_state("TOWER_SPAWN")
        tower:set_texture(Engine.load_texture(_folderpath.."navi_flashman_atlas.og.png"))
        tower:toggle_hitbox(false)
        tower:set_health(50)
        tower:set_facing(player:get_facing())
        tower:set_name("Flash Tower")
        animation:on_complete(function()
            animation:set_state("TOWER_IDLE")
            animation:set_playback(Playback.Loop)
            tower:toggle_hitbox(true)
        end)

        tower.update_func = function(self, dt)
            if tower:get_tile():is_edge() or tower:get_tile():get_state() == TileState.Broken then
                self:delete()
            end
			
                if player.tower_attack == true and player.tower_attack_start == true then
                player.tower_attack_start = false				
                animation:set_state("TOWER_ATTACK")
						
animation:on_frame(10, function()
	print("flash")
			            Engine.play_audio(Engine.load_audio(_modpath.."Chips/Tower/flash.ogg"), AudioPriority.High)
					screen_flash(player, 10)
					blind_all_enemies(player)
        end, true)
				 	
				animation:on_complete(function()					
				player.tower_attack = false
						animation:set_state("TOWER_IDLE")
						animation:set_playback(Playback.Loop)
					end)
					
            end
			
        end

        tower.delete_func = function(self)
	        Engine.play_audio(Engine.load_audio(_folderpath .. "Chips/Tower/explosion.ogg"), AudioPriority.High)		
            animation:set_state("TOWER_DELETE")
			create_explosion_effect(player:get_field(), self:get_current_tile(), Engine.load_texture(_folderpath .. "Chips/Tower/explosion.png"), _folderpath .. "Chips/Tower/explosion.animation", "DEFAULT")
			player.towerspawned = false	
            self:erase()
        end

        tower.can_move_to_func = function(self, tile)
            return true
        end

        if #player:get_tile(player:get_facing(), 1):find_entities(query) <= 0 and player:get_tile(player:get_facing(), 1):get_state() ~= TileState.Broken then
            player:get_field():spawn(tower, player:get_tile(player:get_facing(), 1))
			player.towerspawned = true
        end
    end

    action.action_end_func = function(self)
    
    end

    player:card_action_event(action, ActionOrder.Immediate)
end

function create_explosion_effect(field, tile, hit_texture, hit_anim_path, hit_anim_state)
    local fx = Battle.Artifact.new()
    fx:set_texture(hit_texture, true)
    local fx_sprite = fx:sprite()
    fx_sprite:set_layer(-3)
    local fx_anim = fx:get_animation()
    fx_anim:load(hit_anim_path)
    fx_anim:set_state(hit_anim_state)
    fx_anim:refresh(fx_sprite)
    fx_anim:on_complete(function()
        fx:erase()
    end)
    field:spawn(fx, tile)
    return fx
end

function blind_all_enemies(player)
    local target_list = player:get_field():find_characters(function(other_character)
        return other_character:get_team() ~= player:get_team() and other_character:get_tile():get_team() ~= player:get_team()
    end)
    for index, entity in ipairs(target_list) do
        local spell = Battle.Spell.new(player:get_team())
        spell:set_hit_props(HitProps.new(0, Hit.Blind | Hit.Impact | Hit.Retangible, Element.None, 0, Drag.new()))
        spell.update_func = function()
            spell:get_current_tile():attack_entities(spell)
            spell:erase()
        end
        entity:get_field():spawn(spell, entity:get_tile())
    end
end

function screen_flash(self, time)
    time = time or 3
    local field = self:get_field()
    local whiteout = Battle.Artifact.new()
    whiteout:set_facing(Direction.Right)
    whiteout:set_texture(Engine.load_texture(_modpath.."Chips/Tower/white.png"))
    whiteout:sprite():set_layer(99)

    local anim = whiteout:get_animation()
    anim:load(_modpath.."Chips/Tower/white.animation")
    anim:set_state("WHITEOUT")


    local white = whiteout:sprite()

    white:set_width(2000)
    white:set_height(2000)
    

    white:set_offset(-90, -100)

    anim:refresh(white)

    local lifetime = time
    whiteout.update_func = function(self)
        if lifetime == 0 then 
            self:delete()
            self:hide()
        end

        lifetime = lifetime - 1
    end

    field:spawn(whiteout, field:tile_at(field:width()+1, field:height()+1))

    return whiteout
end
