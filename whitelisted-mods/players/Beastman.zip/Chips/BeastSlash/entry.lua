local DAMAGE = 70

local AUDIO_SLASH = Engine.load_audio(_folderpath.."sfx.ogg")

local TEXTURE_EFFECT = Engine.load_texture(_folderpath.."effect.png")
local ANIMPATH_EFFECT = _folderpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."hitsound.ogg")

local beastslash = {}

function package_init(package)
    package:declare_package_id("com.k1rbyat1na.card.EXE6-052-DrillArm")
    package:set_icon_texture(Engine.load_texture(_folderpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath.."preview.png"))
	package:set_codes({"G","M","W"})

    local props = package:get_card_props()
    props.shortname = "DrillArm"
    props.damage = DAMAGE
    props.time_freeze = false
    props.element = Element.Sword
    props.description = "Knocks enmy 2sq away"
    props.long_description = "Drill attacks 2 squares in front of you! Knocks the enemy away!"
    props.can_boost = true
	props.card_class = CardClass.Standard
	props.limit = 3
end


-------------------------------

-------------------------------
local frame1 = {1, 0.07}
local frame2 = {2, 0.02}
local frame3 = {3, 0.02}
local frame4 = {4, 0.02}
local frame5 = {8, 0.075}
local frame6 = {9, 0.075}
local frame7 = {10, 0.075}
local frame8 = {11, 0.05}
local frame9 = {12, 0.05}
local frame10 = {13, 0.05}
local frame11 = {14, 0.15}
local frame12 = {15, 0.033}
local frame13 = {16, 0.033}
local frame14 = {17, 0.033}
local frame15 = {18, 0.033}
local frame16 = {19, 0.033}
local frame_data = make_frame_data({
 frame1, frame2, frame3, frame4, frame3, frame2, frame1, frame5, frame6, frame7, frame8, frame9, frame10, frame11, frame12, frame13, frame14, frame15, frame16
})

beastslash.card_create_action = function(user, props)
local dark_query = function(o)
    return Battle.Obstacle.from(o) ~= nil and o:get_health() > 0
end

local facing = user:get_facing()
local field = user:get_field()
local team = user:get_team()

local self_tile = user:get_current_tile()
local self_X = self_tile:x()
local self_Y = self_tile:y()

local team_check = function(ent)
    if not user:is_team(ent:get_team()) then
        return true
    end
end

local targeted = false
local tile1_check = false
local tile2_check = false
local tile_array1 = {}
local desired_tile

-- Ajuste para iterar apenas na coluna Y do usuário
local start_j, end_j, step_j = self_Y, self_Y, 1

for i = 1, 6, 1 do
    for j = start_j, end_j, step_j do
        if not targeted then
            local tile1 = field:tile_at(i, j)
            local tile2 = tile1:get_tile(Direction.reverse(facing), 1)
            tile1_check = tile1 and tile1 ~= nil and #tile1:find_characters(team_check) > 0
            tile2_check = tile2 and tile2 ~= nil and not tile2:is_edge() and tile2:is_walkable() and #tile2:find_characters(team_check) <= 0 and #tile2:find_entities(dark_query) <= 0
            if tile1_check and tile2_check then
                print("target found at tile (" .. i .. ";" .. j .. ")")
                table.insert(tile_array1, tile1)
                desired_tile = tile_array1[1]:get_tile(Direction.reverse(facing), 1)
                targeted = true
                break
            end
        end
    end
    if targeted then
        break 
    end
end

local original_tile = user:get_tile()
local is_occupied = function(query)
    return query and not query:is_deleted() and Battle.Character.from(query) ~= nil or query and not query:is_deleted() and Battle.Obstacle.from(query) ~= nil
end

    local action = Battle.CardAction.new(user, "SLASH")
	
	
	
	action:override_animation_frames(frame_data)
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
-------------------
     	            action.can_move_to_func = function(tile)
                return true
            end
-------------------

------------

self:add_anim_action(3, function()
            if targeted and desired_tile and desired_tile ~= original_tile then
                if desired_tile:is_walkable() and not desired_tile:is_edge() then
        desired_tile:add_entity(user) 
		original_tile:remove_entity_by_id(user:get_id())		
	    end
	end
end)

self:add_anim_action(15, function()
user:get_tile()
            user:toggle_counter(true)
        end)

        self:add_anim_action(7, function()
		        local direction = user:get_facing()
		        ------------ 
        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local X_offset_1 = nil
        local X_offset_2 = nil

        if direction == Direction.Right then
            X_offset_1 = X + 1
            X_offset_2 = X + 2
        else
            X_offset_1 = X - 1
            X_offset_2 = X - 2
        end
            create_slash(user, props, team, direction, field, X_offset_1, Y)
		end)

        self:add_anim_action(8, function()
            user:toggle_counter(false)
		end)
		
		self:add_anim_action(10, function()
		Engine.play_audio(AUDIO_SLASH, AudioPriority.High)
		end)
		
        self:add_anim_action(11, function()
		        local direction = user:get_facing()
		        ------------ 
        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local X_offset_1 = nil
        local X_offset_2 = nil

        if direction == Direction.Right then
            X_offset_1 = X + 1
            X_offset_2 = X + 2
        else
            X_offset_1 = X - 1
            X_offset_2 = X - 2
        end
            create_slash(user, props, team, direction, field, X_offset_1, Y)
			create_slash(user, props, team, direction, field, X_offset_1, Y + 1)
			create_slash(user, props, team, direction, field, X_offset_1, Y - 1)
		end)

        self:add_anim_action(16, function()
		        local direction = user:get_facing()
		        ------------ 
        local self_tile = user:get_tile()
        local X = self_tile:x()
        local Y = self_tile:y()

        local X_offset_1 = nil
        local X_offset_2 = nil

        if direction == Direction.Right then
            X_offset_1 = X + 1
            X_offset_2 = X + 2
        else
            X_offset_1 = X - 1
            X_offset_2 = X - 2
        end
            create_slash(user, props, team, direction, field, X_offset_1, Y)
		end)
    end
    action.action_end_func = function()
        user:toggle_counter(false)
		            if targeted and desired_tile and desired_tile ~= original_tile then
                if original_tile:is_walkable() then				
						                original_tile:add_entity(user)
				                desired_tile:remove_entity_by_id(user:get_id())
				end
			end	
    end
    return action
end

function create_slash(owner, props, team, direction, field, spell_X, spell_Y)
    local spell = Battle.Spell.new(team)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Flinch | Hit.Impact | Hit.Drag | Hit.Breaking,
            Element.Sword,
            owner:get_context(),
            Drag.new(direction, 0)
        )
    )
    local anim = spell:get_animation()
    anim:load(_folderpath.."attack.animation")
    anim:set_state("0")
    anim:on_complete(function() spell:erase() end)

    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
    end

    spell.can_move_to_func = function(tile)
		return true
	end

    spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.attack_func = function()
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Highest)
        local hitfx = Battle.Artifact.new()
		hitfx:set_facing(Direction.Right)
		local hitfxanim = hitfx:get_animation()
		hitfx:set_texture(TEXTURE_EFFECT, true)
		hitfxanim:load(ANIMPATH_EFFECT)
		hitfxanim:set_state("DEFAULT")
        hitfxanim:refresh(hitfx:sprite())
        hitfxanim:on_complete(function()
            hitfx:erase()
        end)
        field:spawn(hitfx, spell:get_current_tile())
        spell:shake_camera(3, 0.33)
    end

    field:spawn(spell, spell_X, spell_Y)

    return spell
end

return beastslash