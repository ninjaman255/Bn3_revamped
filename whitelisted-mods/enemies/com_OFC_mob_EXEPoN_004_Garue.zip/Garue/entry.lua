local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "Garue",
        hp = 60,
        damage = 20,
        height = 54,
        move_before_attack = 7,
        current_moves = 7,
        cascade_frame_index = 16,
        shot_type = 1,
        palette = _folderpath.."battle_v1.palette.png"
    }
    if character:get_rank() == Rank.SP then
        character_info.hp = 220
        character_info.damage = 120
        character_info.move_before_attack = 3
        character_info.current_moves = 3
        character_info.cascade_frame_index = 3
        character_info.palette = _folderpath.."battle_sp.palette.png"
    end
    shared_package_init(character, character_info)
end
