
local hit_sfx = Engine.load_audio(_modpath.."shared/hit.ogg")
local shock_sfx = Engine.load_audio(_folderpath.."shock.ogg")
local start_sfx = Engine.load_audio(_folderpath.."startup.ogg")

local shock_yellow = Engine.load_texture(_folderpath.."yellow_shock.png")
local shock_green = Engine.load_texture(_folderpath.."green_shock.png")

local shock_path = _folderpath.."battle_fx50_animations.animation"

local shocker_texture = Engine.load_texture(_folderpath.."shocker.png")
local shocker_path = _folderpath.."boss11_animations.animation"


function card_create_action(user)
    local action = Battle.CardAction.new(user, "HOLY_SHOCK")

    action:set_lockout(make_animation_lockout())
   
    local FRAME_1 = { 1, 0.033 }
    local FRAME_2 = { 2, 0.183 }

    local loop_frame_dur = 4
    local LOOP_1 = {2, 0.066}
    local LOOP_2 = {3, 0.066}
    local LOOP_3 = {4, 0.066}
    local LOOP_4 = {5, 0.066}

    local attack_cooldown_max = 7
    local attack_cooldown = attack_cooldown_max
    local rounds = 8

    local loops = {
        LOOP_1,
        LOOP_2,
        LOOP_3,
        LOOP_4,
    }



    local frames_table = {FRAME_1, FRAME_2}

    local frames_needed = attack_cooldown_max * (rounds + 2)
    local i = 1
    local max = #loops
    while frames_needed > 0
    do
        table.insert(frames_table, loops[i])
        i = i + 1
        if i > max then 
            i = 1
        end
        frames_needed = frames_needed - loop_frame_dur
    end

    --[[
    local FRAMES = make_frame_data({ FRAME_1, FRAME_2, 
        LOOP_1, LOOP_2, LOOP_3, LOOP_4,
        LOOP_1, LOOP_2, LOOP_3, LOOP_4,
        LOOP_1, LOOP_2, LOOP_3, LOOP_4,
        LOOP_1, LOOP_2, LOOP_3, LOOP_4
    })
        ]]
    local FRAMES = make_frame_data(frames_table)
    action:override_animation_frames(FRAMES)


    local target_tiles = {}
    local current_index = 1
    local start_attacking = false
    
    local hit_props = nil
    local shocker = nil
    
    action.execute_func = function()
        action:add_anim_action(3, function()
            Engine.play_audio(start_sfx, AudioPriority.Low)

            target_tiles = get_target_tiles(user)
            start_attacking = true
            hit_props = HitProps.new(
                20 + user:get_attack_level() * 20,
                Hit.Impact | Hit.Flinch | Hit.Flash,
                Element.None, 
                user:get_context(), 
                Drag.None
            )

            shocker = create_shocker(user)
            user:get_field():spawn(shocker, user:get_current_tile())
        end)
    end

    local function do_attack(last_tile)
        if #target_tiles == 0 then return end
        local t = target_tiles[current_index]

        --[[ 
            Avoid doing the same as the last tile. They are spawned in pairs, 
            so last_tile should only be non-nil for the second do_attack call 
            in the pair.

            This can really only happen if the last tile was the tile at 
            #target_tiles and, after shuffling, the new first tile was the 
            same as the last set's final tile. In that case, we should be 
            able to safely swap the current and next index and carry on, 
            except in the case that #target_tiles == 1. If this is so, then 
            we see that the new tile is still the same as the last tile, and 
            we just don't do this attack.
        ]]

        if t ~= nil and last_tile ~= nil and t == last_tile then 
            local c = current_index+1
            -- There is no tile to swap with. This should mean #target_tiles == 1,
            -- in practice, so don't attack
            if c > #target_tiles then 
            --    print("Returned here when #target_tiles == ", #target_tiles)
                return
            end

            target_tiles[c], target_tiles[current_index] = target_tiles[current_index], target_tiles[c]
            t = target_tiles[current_index]

            -- This shouldn't happen.
           -- if t == last_tile then 
               -- return
            --end
        end

        if t then 
            delay_attack(user, t, hit_props)
            current_index = current_index + 1
            return t
        else
            target_tiles = shuffle(target_tiles)
            current_index = 1
            return do_attack(last_tile)
        end

    end

    action.update_func = function()
        if start_attacking then 
            attack_cooldown = attack_cooldown - 1
            if attack_cooldown <= 0 then 
                local t1 = do_attack()
                local t2 = do_attack(t1)

                --[[
                if t2 ~= nil then 
                    print("Attack on ("..t1:x()..", "..t1:y()..") and ("..t2:x()..", "..t2:y()..")")
                else
                    print("Attack on ("..t1:x()..", "..t1:y()..")")
                end
                ]]

                attack_cooldown = attack_cooldown_max
                rounds = rounds - 1
                if rounds <= 0 then 
                    start_attacking = false
                end
            end
        end
    end

    action.action_end_func = function()
        if shocker and not shocker:is_deleted() then 
            shocker:hide()
            shocker:delete()
        end

    end
    return action
end



function delay_attack(user, tile, props)
    local spell = Battle.Spell.new(user:get_team())
    spell.lifetime = 10
    local counter = 0
    spell.update_func = function(self)
        self.lifetime = self.lifetime - 1

        -- Want it to flash for 5, but takes a frame for highlight to happen
        if counter < 6 then 
            tile:highlight(Highlight.Solid)
        end

        if counter == 10 then 
            counter = 0
        end
        
        if self.lifetime == 0 then 
            if not user:is_deleted() and user:get_health() > 0 then 
                Engine.play_audio(shock_sfx, AudioPriority.Low)

                local should_crack = check_tile(user:get_team(), tile)
                spawn_attack(self, tile, props, should_crack)
            end
            self:delete()
        end

        counter = counter + 1

    end

    user:get_field():spawn(spell, tile)
end

function create_shocker(user)
    local spell = Battle.Spell.new(user:get_team())

    local sprite = spell:sprite()

    spell:set_texture(shocker_texture)
    spell:set_facing(user:get_facing())
    sprite:set_layer(-1)

    local anim = spell:get_animation()
    anim:load(shocker_path)
    anim:set_state("10")
    anim:set_playback(Playback.Loop)

    anim:refresh(sprite)

    return spell
end


function check_tile(team, tile)
    local found = #(tile:find_characters(function(c)
        return not c:is_deleted() and c:get_team() ~= team and c:get_health() > 0 
    end)) > 0

    found = found or #(tile:find_obstacles(function(o)
        return not o:is_deleted() and o:get_team() ~= team and o:get_health() > 0 
    end)) > 0

    return found
end

function spawn_attack(user, tile, props, should_crack)

    local artifact = Battle.Artifact.new()
    local sprite = artifact:sprite()
    local texture = shock_green
    if should_crack then 
        texture = shock_yellow
    end

    artifact:set_texture(texture)
    artifact:set_facing(user:get_facing())
    
    sprite:set_layer(-1)

    local anim = artifact:get_animation()
    anim:load(shock_path)
    anim:set_state("0")

    anim:on_complete(function()
        artifact:delete()
    end)

    anim:refresh(sprite)


    local spell = Battle.Spell.new(user:get_team())
    spell:set_hit_props(props)

    spell.on_spawn_func = function(self)
        local t = self:get_current_tile()
        if should_crack then 
            if t:get_state() == TileState.Cracked then 
                t:set_state(TileState.Broken)
            else
                t:set_state(TileState.Cracked)
            end
        end
        t:attack_entities(self)
    end

    spell.update_func = function(self)
        self:delete()
    end
    
    spell.attack_func = function()
        Engine.play_audio(hit_sfx, AudioPriority.Low)
    end
    

    user:get_field():spawn(spell, tile)
    user:get_field():spawn(artifact, tile)
end

function get_target_tiles(user)
    local facing = user:get_facing()

    local tiles = {}

    local cur_tile = user:get_tile(facing, 1)
    local adjacent = true

    while(cur_tile and not cur_tile:is_edge())
    do
        if adjacent then 
            local t1 = cur_tile:get_tile(Direction.Up, 1)
            local t2 = cur_tile:get_tile(Direction.Down, 1)
            
            if t1 and not t1:is_edge() then 
                table.insert(tiles, t1)
            end

            if t2 and not t2:is_edge() then 
                table.insert(tiles, t2)
            end
        else
            table.insert(tiles, cur_tile)
        end

        adjacent = not adjacent

        cur_tile = cur_tile:get_tile(facing, 1)
    end


    return shuffle(tiles)
end

function shuffle(tiles)
    for i = #tiles, 2, -1
    do
        local j = math.random(i)
        tiles[i], tiles[j] = tiles[j], tiles[i]
    end

    return tiles
end

return card_create_action