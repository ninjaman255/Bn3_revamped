

local drill = {}



function create_tackle(user, props)
	local spell = Battle.Obstacle.new(Team.Other)
	spell:set_facing(user:get_facing())
	spell.slide_started = false
	spell:set_texture(Engine.load_texture(_folderpath.."drillman.png"), true)
	local direction = spell:get_facing()
	Engine.play_audio(Engine.load_audio(_folderpath.."Up.ogg", true), AudioPriority.High)
	local max_tiles = 7
	local tiles_moved = 0
	spell.attack_func = function(self)
		local tile = self:get_tile()
		local hitbox = Battle.Hitbox.new(Team.Other)
		hitbox:set_hit_props(props)
		user:get_field():spawn(hitbox, tile)
	end
	
	local anim = spell:get_animation()
	anim:load(_folderpath.."drillman.animation", true)
	anim:set_state("DRILL")
	
	spell.update_func = function(self, dt) 
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if self:get_current_tile():is_edge() and self.slide_started then
                self:delete()
            end 
			if tiles_moved >= max_tiles then
				self:delete()
			end
            local dest = self:get_tile(direction, 1)
            local ref = self
            self:slide(dest, frames(7), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
			
			tiles_moved = tiles_moved + 1
        end
    end
	spell.collision_func = function(self, other)
	
	    if Battle.Obstacle.from(other) ~= nil then
        local obstacle = Battle.Obstacle.from(other)
        obstacle:delete()
   end
	
		self.has_hit = true
		Engine.play_audio(Engine.load_audio(_folderpath.."hurt.ogg", true), AudioPriority.High)
		
		
	end

		spell:get_animation():on_complete(function()
			spell:erase()
		end)

    spell.delete_func = function(self)
				user:reveal()
			user:toggle_hitbox(true)
			user:share_tile(false)
		self:erase()
    end

    spell.can_move_to_func = function(tile)
		print(tile)
        if tile then
			if tile:is_walkable() then
				return true
			else
				return true
			end
		end
		return false
    end

	return spell
end

drill.card_create_action = function(user, props)
		local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
		local frame1 = {1, 0.55}
		local LONG_IDLE = make_frame_data({frame1})
		local pain = ((10 * user:get_attack_level()) + 40)
		local props = HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch, 
			Element.Break,
			user:get_context(),
			Drag.None
		)
		local spell = create_tackle(user, props)
		action:override_animation_frames(LONG_IDLE)
		action.execute_func = function(self, user)
			user:hide()
			user:toggle_hitbox(false)
			user:share_tile(true)
			user:get_field():spawn(spell, user:get_tile())
		end
		action.action_end_func = function(self)	

		end
		action.can_move_to_func = function(tile)
return true
		end
		return action
	end

return drill