local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")
local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"

local teleport_animation_path =  _folderpath.."teleport.animation"
local teleport_texture_path = _folderpath.."teleport.png"
local teleport_texture = Engine.load_texture(teleport_texture_path)
local FIREBALL_TEXTURE = Engine.load_texture(_folderpath.."fireball.png")
local FIREBALL_ANIMPATH = _folderpath.."fireball.animation"
local FIREBALL_AUDIO = Engine.load_audio(_folderpath.."EXE4_110.ogg")

local HEAT_TEXTURE = Engine.load_texture(_folderpath.."heat.png")
local HEAT_ANIMPATH = _folderpath.."heat.animation"
local HEAT_AUDIO = Engine.load_audio(_folderpath.."EXE4_132.ogg")

local debug = false
local function debug_print(text)
    if debug then
        print("[Garu] "..text)
    end
end

local MobTracker = include("mob_tracker.lua")
local left_mob_tracker = MobTracker:new()
local right_mob_tracker = MobTracker:new()
function get_tracker_from_direction(facing)
    if facing == Direction.Left then
        return left_mob_tracker
    elseif facing == Direction.Right then
        return right_mob_tracker
    end
end

function advance_a_turn_by_facing(facing)
    local mob_tracker = get_tracker_from_direction(facing)
    return mob_tracker:advance_a_turn()
end

function get_active_mob_id_for_same_direction(facing)
    local mob_tracker = get_tracker_from_direction(facing)
    return mob_tracker:get_active_mob()
end

function add_enemy_to_tracking(enemy)
    local facing = enemy:get_facing()
    local id = enemy:get_id()
    local mob_tracker = get_tracker_from_direction(facing)
    mob_tracker:add_by_id(id)
end

function remove_enemy_from_tracking(enemy)
    local facing = enemy:get_facing()
    local id = enemy:get_id()
    local mob_tracker = get_tracker_from_direction(facing)
    mob_tracker:remove_by_id(id)
end

-- Required function, main package information
function package_init(self, character_info)
    debug_print("package_init called")
    -- Load character resources
    self.texture = Engine.load_texture(_folderpath.."battle.greyscaled.png")
    self.animation = self:get_animation()
    self.animation:load(_folderpath.."battle.animation")
    -- Set up character meta
    self:set_texture(self.texture, true)
    self:set_height(54)
    self:share_tile(false)
    self:set_explosion_behavior(3, 1, false)
    self:set_offset(0, 0)
    self:set_name(character_info.name)
    self:set_element(Element.Fire)
    self:set_palette(Engine.load_texture(character_info.palette))
    self:set_health(character_info.hp)
    self.damage = character_info.damage
    self.shot_type = character_info.shot_type
    self.move_before_attack = character_info.move_before_attack
    self.current_moves = character_info.current_moves
    self.cascade_frame_index = character_info.cascade_frame_index

    --defense rules
    --[[
    self.defense = Battle.DefenseVirusBody.new()
    self:add_defense_rule(self.defense)
    ]]

    -- Initial state
    self.animation:set_state("SPAWN")
    self.animation:set_playback(Playback.Loop)
    self.frames_between_actions = 40
    self.ai_wait = self.frames_between_actions
    self.ai_taken_turn = false

    self.init_func = function()
        self.animation:set_state("IDLE")
        self.animation:set_playback(Playback.Loop)
    end

    self.update_func = function(self, dt)
        take_turn(self)
        if self.current_moves <= 0 then
            initiate_attack(self)
        end
    end

    self.battle_start_func = function(self)
        debug_print("battle_start_func called")
        local field = self:get_field()
        add_enemy_to_tracking(self)
        local mob_sort_func = function(a, b)
            local var_a = Battle.Character.from(field:get_entity(a)):get_rank()
            local var_b = Battle.Character.from(field:get_entity(b)):get_rank()
            return var_a < var_b
        end
        left_mob_tracker:sort_turn_order(mob_sort_func)
        right_mob_tracker:sort_turn_order(mob_sort_func)
        self.animation:set_state("IDLE")
        self.animation:set_playback(Playback.Loop)
    end
    self.battle_end_func = function(self)
        debug_print("battle_end_func called")
        left_mob_tracker:clear()
        right_mob_tracker:clear()
    end
    self.on_spawn_func = function(self, spawn_tile)
        debug_print("on_spawn_func called")
        left_mob_tracker:clear()
        right_mob_tracker:clear()
    end
    self.can_move_to_func = function(tile)
        debug_print("can_move_to_func called")
        return is_tile_free_for_movement(tile, self)
    end
    self.delete_func = function(self)
        debug_print("delete_func called")
        remove_enemy_from_tracking(self)
    end
end

function take_turn(self)
    local id = self:get_id()
    if self.ai_wait > 0 or self.ai_taken_turn then
        self.ai_wait = self.ai_wait - 1
        return
    end

    local moved_randomly = move_at_random(self)

    if moved_randomly then
        self.ai_wait = self.frames_between_actions
        self.ai_taken_turn = false
        self.current_moves = self.current_moves - 1
        return
    else
        self.ai_wait = self.frames_between_actions
        self.ai_taken_turn = false
        return
    end
end

local function find_best_target(virus)
    if not virus or virus and virus:is_deleted() then return end
    local target = virus:get_target() --Grab a basic target from the virus itself.
    local field = virus:get_field() --Grab the field so you can scan it.
    local query = function(c)
        return c:get_team() ~= virus:get_team() --Make sure you're not targeting the same team, since that won't work for an attack.
    end
    local potential_threats = field:find_characters(query) --Find CHARACTERS, not entities, to attack.
    local goal_hp = 999999 --Start with a ridiculous health.
    if #potential_threats > 0 then --If the list is bigger than 0, we go in to a loop.
        for i = 1, #potential_threats, 1 do --The pound sign, or hashtag if you're more familiar with that term, is used to denote length of a list or array in lua.
            local possible_target = potential_threats[i] --Index with square brackets.
            --Make sure it exists, is not deleted, and that its health is less than the goal HP. First one always will be.
            if possible_target and not possible_target:is_deleted() and possible_target:get_health() <= goal_hp then
                --Make it the new target. This way the lowest HP target is attacked.
                target = possible_target
            end
        end
    end
    --Return whoever the target is.
    return target
end

function initiate_attack(self)
    local id = self:get_id()
    if self.ai_wait > 0 or self.ai_taken_turn then
        self.ai_wait = self.ai_wait - 1
        return
    end

    local moved = move_towards_character(self)

    if not moved then
        return
    end

    self.current_moves = self.move_before_attack

    local fireball_action = action_fireball(self)
    local next_action = fireball_action
    next_action.action_end_func = function()
        local facing = self:get_facing()
        self.ai_wait = self.frames_between_actions
        self.ai_taken_turn = false
        advance_a_turn_by_facing(facing)
    end
    self:card_action_event(next_action, ActionOrder.Voluntary)
end

function move_at_random(self)
    local field = self:get_field()
    local tile = self:get_current_tile()
    local target_tile = nil
    local tile_array = {}
    local moved = false
    for x = 1, 6, 1 do
        for y = 1, 3, 1 do
            local prospective_tile = field:tile_at(x, y)
            if self.can_move_to_func(prospective_tile) then
                table.insert(tile_array, prospective_tile)
            end
        end
    end
    if #tile_array == 0 then return false end
    target_tile = tile_array[math.random(1, #tile_array)]
    if target_tile then
        target_tile:reserve_entity_by_id(self:get_id())
        moved = self:teleport(target_tile, ActionOrder.Immediate)
        if moved then
            self:set_facing(target_tile:get_facing())
            spawn_visual_artifact(tile, self, teleport_texture, teleport_animation_path, "BIG_TELEPORT_FROM", 0, -20)
            spawn_visual_artifact(target_tile, self, teleport_texture, teleport_animation_path, "BIG_TELEPORT_TO", 0, -20)
        end
    end
    return moved
end

function move_towards_character(self)
    local target_character = find_best_target(self)
    if target_character == nil then return false end
    local tile = self:get_current_tile()
    local moved = false
    local target_movement_tile = nil
    for i = 1, 6, 1 do
        if target_movement_tile ~= nil then
            break
        else
            local check_tile = target_character:get_tile(target_character:get_facing(), i)
            if self.can_move_to_func(check_tile) then
                target_movement_tile = check_tile
            end
        end
    end
    if target_movement_tile then
        target_movement_tile:reserve_entity_by_id(self:get_id())
        moved = self:teleport(target_movement_tile, ActionOrder.Immediate)
        if moved then
            self:set_facing(target_movement_tile:get_facing())
            spawn_visual_artifact(tile, self, teleport_texture, teleport_animation_path, "BIG_TELEPORT_FROM", 0, -20)
            spawn_visual_artifact(target_movement_tile, self, teleport_texture, teleport_animation_path, "BIG_TELEPORT_TO", 0, -20)
        end
    end
    return moved
end

function action_fireball(character)
    debug_print("started fireball action")
    local action_name = "fireball"
    local team = character:get_team()
    local field = character:get_field()
    local facing = character:get_facing()
    debug_print('action '..action_name)
    local action = Battle.CardAction.new(character, "ATTACK")
    action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        self:add_anim_action(4, function()
            local tile = character:get_tile(facing, 1)
            --spawn_fireball(character, tile, facing, character.damage, character.cascade_frame_index)
            create_attack(character, Element.Fire, character.damage, character.shot_type, team, facing, field, tile)
        end)
    end
    character.ai_taken_turn = true
    return action
end

function is_tile_free_for_movement(tile, character)
    --Basic check to see if a tile is suitable for a chracter of a team to move to
    if not tile then return false end --If the tile isn't real, lol.
    if not character:is_team(tile:get_team()) then return false end --If it's red and we're blue / blue and we're red, lol.
    if not tile:is_walkable() then return false end --If it's not walkable and we're a Spikey, lol.
    local occupants = tile:find_entities(function(ent) --Setup filtering for obstacles & characters.
        if Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil then
            return true
        end
    end)
    if #occupants > 0 then --If it's occupied by an obstacle or character, lol.
        return false
    end
    --Cool let's go there.
    return true
end

function spawn_visual_artifact(tile, character, texture, animation_path, animation_state, position_x, position_y)
    local field = character:get_field()
    local visual_artifact = Battle.Artifact.new()
    visual_artifact:set_texture(texture, true)
    local anim = visual_artifact:get_animation()
    anim:load(animation_path)
    anim:set_state(animation_state)
    anim:on_complete(function()
        visual_artifact:delete()
    end)
    visual_artifact:sprite():set_offset(position_x, position_y)
    field:spawn(visual_artifact, tile:x(), tile:y())
end

function create_attack(user, element, damage, shot_type, team, facing, field, tile)
    debug_print("in spawn fireball")
    local spawn
    spawn = function()
        if tile == nil or tile:is_edge() then return end

		local spell = Battle.Spell.new(team)
		spell.slide_started = false
		spell:set_hit_props(
    	    HitProps.new(
    	        0, 
    	        Hit.Impact, 
    	        Element.None,
    	        user:get_id(), 
    	        Drag.None
    	    )
    	)
		spell:set_facing(facing)
        spell:highlight_tile(Highlight.Solid)
        local sprite = spell:sprite()
        sprite:set_layer(-3)
        sprite:set_texture(FIREBALL_TEXTURE)
        local animation = spell:get_animation()
        animation:load(FIREBALL_ANIMPATH)
        animation:set_state("DEFAULT")
        animation:set_playback(Playback.Loop)
        animation:refresh(sprite)
        spell.on_spawn_func = function()
            Engine.play_audio(FIREBALL_AUDIO, AudioPriority.Low)
        end
        local query_TeamHP = function(ent)
            if not user:is_team(ent:get_team()) and ent:get_health() > 0 then
                return true
            end
        end
		spell.update_func = function(self)
            local self_tile = self:get_current_tile()
            local ref = self
            if      element == Element.Fire then
                if self_tile ~= nil and
                    not self_tile:is_edge() and
                    #self_tile:find_characters(query_TeamHP) <= 0 and 
                    #self_tile:find_obstacles(query_TeamHP) <= 0 and 
                    self_tile:get_state() == TileState.Grass
                    then
                    self_tile:set_state(TileState.Normal)
                end
            elseif  element == Element.Aqua then
                if self_tile ~= nil and
                    not self_tile:is_edge() and
                    #self_tile:find_characters(query_TeamHP) <= 0 and 
                    #self_tile:find_obstacles(query_TeamHP) <= 0 and 
                    self_tile:get_state() == TileState.Lava
                    then
                    self_tile:set_state(TileState.Normal)
                end
            end
            
    	    self:get_current_tile():attack_entities(self)
    	    if self:is_sliding() == false then
    	        if self:get_current_tile():is_edge() and self.slide_started then 
    	            self:delete()
    	        end
    	        local dest = self:get_tile(facing, 1)
    	        self:slide(dest, frames(user.cascade_frame_index), frames(0), ActionOrder.Voluntary, function()
    	            ref.slide_started = true 
    	        end)
    	    end
    	end
    	spell.attack_func = function(self, ent)
            create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_current_tile())													        --current tile
			if 		shot_type == 1 then
				create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(facing, 1))													    --forward
			elseif	shot_type == 2 then
				create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.join(Direction.Up, facing), 1))						--up-forward
				create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.join(Direction.Down, facing), 1))					    --down-forward
			elseif	shot_type == 3 then
				create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.Up, 1))												--up
				create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.Down, 1))											    --down
			else
				create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(facing, 1))													    --forward
				create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.Up, 1))												--up
				create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.Down, 1))											    --down
				create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.reverse(facing), 1))									--back
				create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.join(Direction.Up, facing), 1))						--up-forward
				create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.join(Direction.Down, facing), 1))					    --down-forward
				create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.join(Direction.Up, Direction.reverse(facing)), 1))	    --up-back
				create_attack2(user, element, damage, shot_type, team, facing, field, ent:get_tile(Direction.join(Direction.Down, Direction.reverse(facing)), 1))	--down-back
			end
    	end
		spell.collision_func = function(self, ent)
			self:delete()
		end
		spell.battle_end_func = function(self)
			self:delete()
		end
		spell.can_move_to_func = function(tile)
    	    return true
    	end
    	spell.delete_func = function(self)
			self:erase()
    	end
		field:spawn(spell, tile)
	end
    spawn()
end

function create_attack2(user, element, damage, shot_type, team, facing, field, tile)
    local spawn
    spawn = function()
        if tile == nil or tile:is_edge() then return end

    	local spell = Battle.Spell.new(team)
    	spell:set_facing(facing)
    	spell:set_hit_props(
    	    HitProps.new(
    	        damage, 
    	        Hit.Impact | Hit.Flinch | Hit.Flash, 
    	        element,
    	        user:get_id(), 
    	        Drag.None
    	    )
    	)
		local anim = spell:get_animation()
		anim:load(_folderpath.."testdot.animation")
		anim:set_state("0")
		anim:on_complete(function() spell:delete() end)
		local query_TeamHP = function(ent)
            if not user:is_team(ent:get_team()) and ent:get_health() > 0 then
                return true
            end
        end
    	spell.update_func = function(self)
            local self_tile = self:get_current_tile()
            self_tile:attack_entities(self)
			if 		element == Element.Aqua then
				if self_tile ~= nil and
					not self_tile:is_edge() and
					#self_tile:find_characters(query_TeamHP) <= 0 and 
					#self_tile:find_obstacles(query_TeamHP) <= 0 and 
					self_tile:get_state() == TileState.Lava
					then
					self_tile:set_state(TileState.Normal)
				end
			elseif	element == Element.Fire then
				if self_tile ~= nil and
					not self_tile:is_edge() and
					#self_tile:find_characters(query_TeamHP) <= 0 and 
					#self_tile:find_obstacles(query_TeamHP) <= 0 and 
					self_tile:get_state() == TileState.Grass
					then
					self_tile:set_state(TileState.Normal)
				end
			end
    	end
		spell.attack_func = function(self, ent)
			if Battle.Obstacle.from(ent) == nil then
                --[[
				if Battle.Player.from(user) ~= nil then
					Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
				end
                ]]
			else
				Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
			end
		end
		spell.battle_end_func = function(self)
			spell:delete()
		end
		spell.can_move_to_func = function(tile)
			return true
		end
		spell.delete_func = function(self)
			spell:erase()
		end
		if 		element == Element.Aqua then
			Engine.play_audio(BUBBLE_AUDIO, AudioPriority.Low)
			create_effect(facing, BUBBLE_TEXTURE, BUBBLE_ANIMPATH, "0", 0, 0, false, -9, field, tile)
		elseif 	element == Element.Fire then
			Engine.play_audio(HEAT_AUDIO, AudioPriority.Low)
			create_effect(facing, HEAT_TEXTURE, HEAT_ANIMPATH, "0", 0, 0, false, -9, field, tile)
		else
			create_effect(facing, BURST_TEXTURE, BURST_ANIMPATH, "0", 0, 0, false, -9, field, tile)
		end
		field:spawn(spell, tile)
	end
    spawn()
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return package_init
