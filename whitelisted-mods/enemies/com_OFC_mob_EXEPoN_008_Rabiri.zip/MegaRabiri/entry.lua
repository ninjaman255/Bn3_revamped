local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "M-Rabiri",
        hp = 120,
        damage = 60,
        palette = _folderpath.."battle_v3.palette.png",
        height = 44,
        ring_speed = 2,
        frames_between_actions = 18,
        fast_hop_frames = 4,
        move_ver = 3
    }
    shared_package_init(character, character_info)
end
