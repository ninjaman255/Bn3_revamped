nonce = function() end

local DAMAGE = 10 --default damage (should be overriden by caller with action.damage)
local sub_folder_path = _folderpath
local WAVE_TEXTURE = Engine.load_texture(sub_folder_path.."shockwave.png")
local AUDIO = Engine.load_audio(sub_folder_path.."shockwave.ogg")
local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."hitsound.ogg")
local harpoon = {

}

harpoon.card_create_action = function(actor, props)
local action = Battle.CardAction.new(actor, "PLAYER_SHOOTING")
	
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
			local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(Engine.load_texture(_folderpath.."navi_bubbleman_atlas.og.png"), true)
		buster:sprite():set_layer(-1)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(_folderpath.."bubbleman.animation")
		buster_anim:set_state("BUSTER2")
	
	
self:add_anim_action(3, function()
		local cannonshot = create_iceslash(user, props)
		local tile = user:get_tile(user:get_facing(), 1)
		actor:get_field():spawn(cannonshot, tile)
		end)
	end
    return action
end

function create_iceslash(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())

	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flash,
			Element.Aqua,
			user:get_context(),
			Drag.None
		)
	)
	local anim = spell:get_animation()
	spell:set_texture(WAVE_TEXTURE, true)
	anim:load(sub_folder_path.."shockwave.animation")
	anim:set_state("DEFAULT")
spell.update_func = function(self, dt)
    self:get_tile():attack_entities(self)
    if not self.delay_started then
        self.delay_frames = self.delay_frames or 1 
        self.delay_frames = self.delay_frames - 1
        if self.delay_frames <= 0 then
            self.delay_started = true 
        end
    elseif self:is_sliding() == false then
        local dest = self:get_tile(spell:get_facing(), 1)
        if dest:is_walkable() then
            if self:get_current_tile():is_edge() and self.slide_started then 
                self:delete()
            end 

            local ref = self
            self:slide(dest, frames(2), frames(0), ActionOrder.Voluntary, 
                function()
                    ref.slide_started = true 
                end
            )
        else
            self:delete() 
        end
    end
end
    	spell.collision_func = function(self, other)
        create_basic_effect(user:get_field(), self:get_current_tile(), Engine.load_texture(_folderpath .. "effect.png"), _folderpath .. "effect.animation", "AQUA")
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)		
		self:delete()
    	end
	spell.delete_func = function(self)
		self:erase()
	end
	spell.can_move_to_func = function(tile)
		return true
	end

	Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end

function create_basic_effect(field, tile, hit_texture, hit_anim_path, hit_anim_state)
    local fx = Battle.Artifact.new()
    fx:set_texture(hit_texture, true)
    local fx_sprite = fx:sprite()
    fx_sprite:set_layer(-3)
    local fx_anim = fx:get_animation()
    fx_anim:load(hit_anim_path)
    fx_anim:set_state(hit_anim_state)
    fx_anim:refresh(fx_sprite)
    fx_anim:on_complete(function()
        fx:erase()
    end)
    field:spawn(fx, tile)
    return fx
end

return harpoon