local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "Roundaba",
        hp = 180,
        damage = 80,
        palette = _folderpath.."palette.png",
        height = 44,
        frames_between_actions = 78,
        boomerang_speed = 5,
        move_speed = 50,
    }
    shared_package_init(character, character_info)
end