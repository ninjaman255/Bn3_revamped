local HIT_SFX = Engine.load_audio(_modpath.."shared_resources/hit.ogg")
local SLAM_SFX = Engine.load_audio(_folderpath.."impact.ogg")
local BREAK_SFX = Engine.load_audio(_folderpath.."rockbreak.ogg")

local HIT_TEXTURE = Engine.load_texture(_folderpath.."overlay_fx05_animations.png")
local ROCK_TEXTURE = Engine.load_texture(_folderpath.."rock.png")
local MOVE_TEXTURE = Engine.load_texture(_folderpath.."move.png")

-- For some reason, can't math.random with negatives right now. I'm using a function like this for now. Come back and remove it later maybe, or add a range
-- If I keep it, add ranges and also round them off to be even (proper pixels)
function get_random_offset()
    local x = math.random(0, 40)
    local y = math.random(10, 40)
    
    x = x - 20
    y = y * -1

    return {x = x, y = y}
end

function card_create_action(user)
    local action = Battle.CardAction.new(user, "GUTS_HAMMER")

    action.execute_func = function(self)
        action:add_anim_action(6, function()
            if user:get_tile(user:get_facing(), 1):is_walkable() then 
                crack_random_enemy_tile(user)
                shake(user, 150, 40)
                Engine.play_audio(SLAM_SFX, AudioPriority.Low)
                drop_rocks(user, 3, 29)
            end

            hammer_attack(user)
        end)
    end

    return action
end

function hammer_attack(user)
    local field = user:get_field()

    local spell = Battle.Spell.new(user:get_team())
    local props = HitProps.new(
        50 + 20 * user:get_attack_level(),
        Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking,
        Element.Break, 
        user:get_context(),
        Drag.None
    )

    spell:set_hit_props(props)

    spell.update_func = function(self)
        self:get_current_tile():attack_entities(self)
        self:delete()
    end

    spell.attack_func = function(self, other)
        local o = get_random_offset()
        local hit_effect = graphic_init("artifact", o.x, o.y, HIT_TEXTURE, "overlay_fx05_animations.animation", -3, "8", self, self:get_facing(), true)
        self:get_field():spawn(hit_effect, other:get_current_tile())
        Engine.play_audio(HIT_SFX, AudioPriority.Low)
    end

    field:spawn(spell, user:get_tile(user:get_facing(), 1))
end

function crack_random_enemy_tile(user)
    local team = user:get_team()
    local field = user:get_field()
    local tiles = field:find_tiles(function(t)
        return not t:is_edge() and t:get_team() ~= team
    end)

    local tile_to_crack = tiles[math.random(1, #tiles)]
    if tile_to_crack and tile_to_crack:is_walkable() then
        if tile_to_crack:get_state() == TileState.Cracked then 
            tile_to_crack:set_state(TileState.Broken)
        else
            tile_to_crack:set_state(TileState.Cracked)
        end
    end

end

function shake(user, power, duration)
    local artifact = Battle.Artifact.new()
    local time = 0

    artifact.update_func = function(self)
        
        self:shake_camera(power, 0.0166)
        if time == duration then 
            self:delete()
        end
  
        time = time+1
    end

    user:get_field():spawn(artifact, 1, 1)
end


function drop_rocks(user, num_rocks, delay)
    if num_rocks <= 0 then return end
    local team = user:get_team()
    local field = user:get_field()

    local spell = Battle.Spell.new(team)
    local tile1 = nil
    local tile2 = nil
    local counter1 = 13
    local counter2 = 26

    local spawn_tiles = {}

    local tile_filter = function(tile)
        return not tile:is_edge() and tile:get_team() ~= team
    end
    local enemy_filter = function(character)
        return character:get_team() ~= team
    end

    local tile_list = field:find_tiles(tile_filter)
    
    local enemy_list = field:find_nearest_characters(user, enemy_filter)

    -- First spawn tile should target an enemy
    if enemy_list[1] then 
        spawn_tiles[1] = enemy_list[1]:get_current_tile()
    else
        spawn_tiles[1] = tile_list[math.random(1, #tile_list)]
    end

    local props = HitProps.new(
        50 + 20 * user:get_attack_level(),
        Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking,
        Element.Break, 
        user:get_context(),
        Drag.None
    )

    -- Allow possible duplicate roll, but do not spawn them
    for i=1, num_rocks-1
    do
        local t = tile_list[math.random(1, #tile_list)]
        local not_dupe = true
        for _k, v in ipairs(spawn_tiles)
        do
            if t == v then 
                not_dupe = false
                break
            end
        end

        if not_dupe then 
            table.insert(spawn_tiles, t)
        end
    end


    spell.update_func = function(self)
        if delay <= 0 then 
            for i=1, #spawn_tiles
            do
                -- User could be deleted by the time this happens. The spell has the same team and facing, so it's good here
                create_rock(self, spawn_tiles[i], props)
            end
            self:delete()
        end
       
        delay = delay - 1
    end

    field:spawn(spell, 0, 0)
end

-- Hits on 27, appears on the top of screen on 5 when at bottom row, flashes for 12-14 before shadow appears?
function create_rock(user, target_tile, props)
    local field = user:get_field()

    local rock = graphic_init("spell", 0, 0, ROCK_TEXTURE, "rock.animation", -1, "0", user, user:get_facing())
    
    local speed = 6
    local time = 0
    local initial_height = 332
   -- local acceleration = initial_height/(fall_time*fall_time)
    rock:set_elevation(speed*72)
    rock:show_shadow(true)
    rock:set_shadow(1)

    rock:set_hit_props(props)

    local function rock_break(tile)
        Engine.play_audio(BREAK_SFX, AudioPriority.High)

        local piece1 = graphic_init("artifact", 0, 0, ROCK_TEXTURE, "rock.animation", -2, "1", rock, rock:get_facing())
        piece1.time = -6
        piece1.flash_count = 0
        piece1:show_shadow(true)
        piece1:set_shadow(1)
        local piece2 = graphic_init("artifact", 0, 0, ROCK_TEXTURE, "rock.animation", -2, "1", rock, rock:get_facing())
        piece2.time = -8
        piece2.flash_count = 0
        piece2:show_shadow(true)
        piece2:set_shadow(1)


        piece1.update_func = function(self)
            local time = self.time
            if self:get_elevation() >= 0 then 

                self:set_offset(self:get_offset().x + 4, 0)
                self:set_elevation(-1*(time*time)/2 + 20)
                
            else
                if time % 4 < 2 then
                    self:hide()
                    if self.flash_count > 3 then 
                        self:delete()
                    end
                else
                    self:reveal()
                    self.flash_count = self.flash_count + 1
                end 
                
            end
            
            self.time = self.time+1

        end

        piece2.update_func = function(self)
            local time = self.time
            if self:get_elevation() >= 0 then 

                self:set_offset(self:get_offset().x - 2, 0)
                self:set_elevation(-1*(time*time)/3 + 30)
                
            else
                if time % 4 < 2 then
                    self:hide()
                    if self.flash_count > 3 then 
                        self:delete()
                    end
                else
                    self:reveal()
                    self.flash_count = self.flash_count + 1
                end 
                
            end

            self.time = self.time+1


        end

        field:spawn(piece1, tile)
        field:spawn(piece2, tile)
    end

    rock.broken = false
    rock.update_func = function(self)
        local elev = self:get_elevation()
        local t = self:get_current_tile()
        if elev <= 60 then 
            t:attack_entities(self)
    
        end

        if self:get_elevation() <= 0 then 
            if t:is_walkable() then 
                rock_break(t)
            else
                local hit_effect = graphic_init("artifact", 0, 0, MOVE_TEXTURE, "move.animation", -3, "0", self, self:get_facing(), true)
                self:get_field():spawn(hit_effect, t)
            end
            
            self:delete()

            return
        end

        self:set_elevation(self:get_elevation() - speed)

        time = time + 1
    end

    -- I'm pretty sure we'll end up breaking twice somewhere, but I might've covered it
    rock.collision_func = function(self, other)
        if not self.broken then 
            rock_break(self:get_current_tile())
        end
        if not self:is_deleted() then 
            self:delete()
        end
    end

    rock.attack_func = function(self, other)
        local o = get_random_offset()
        local hit_effect = graphic_init("artifact", o.x, o.y, HIT_TEXTURE, "overlay_fx05_animations.animation", -3, "1", self, self:get_facing(), true)
        self:get_field():spawn(hit_effect, other:get_current_tile())

        Engine.play_audio(HIT_SFX, AudioPriority.Low)
    end

    field:spawn(rock, target_tile)
end


function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
    flip = flip or false
    delete_on_complete = delete_on_complete or false
    facing = facing or nil
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()

    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())

    end

    graphic:sprite():set_layer(layer)
    graphic:never_flip(flip)
    graphic:set_texture(texture, false)
    if facing then 
        graphic:set_facing(facing)
    end
    
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    anim:load(_folderpath..animation)

    anim:set_state(state)
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

return card_create_action