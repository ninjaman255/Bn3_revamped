local DAMAGE = 0

local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")

local STEAL_TEXTURE = Engine.load_texture(_folderpath.."steal.png")
local STEAL_ANIMPATH = _folderpath.."steal.animation"
local STEAL_AUDIO1 = Engine.load_audio(_folderpath.."EXE4_222.ogg")
local STEAL_AUDIO2 = Engine.load_audio(_folderpath.."EXE4_202.ogg")

local steal = {
    type = 2,
}

steal.card_create_action = function(actor)
    print("in create_card_action()!")
	local props = Battle.CardProperties.new()
	props.damage = 10
	props.shortname = "AreaStel"
	props.time_freeze = true
    local action = Battle.CardAction.new(actor, "")
	action:set_metadata(props)
	local original_offset = actor:get_offset()
    local LONG_FRAME = make_frame_data({{0, 1.3}})
	action:override_animation_frames(LONG_FRAME)
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
        print("in custom card action execute_func()!")
		local facing = user:get_facing()
        local field = user:get_field()
		local team = user:get_team()

		local tile = nil
        if steal.type == 2 then
		    if team == Team.Red then
		    	if facing == Direction.Right then
		    		tile = field:tile_at(1, 2)
		    	else
		    		tile = field:tile_at(6, 2)
		    	end
		    else
		    	if facing == Direction.Left then
		    		tile = field:tile_at(6, 2)
		    	else
		    		tile = field:tile_at(1, 2)
		    	end
		    end
        else
            tile = user:get_current_tile()
        end
        local tile_array = {}
		local count = 1
		local max = 6
		local tile_front = nil
		local tile_up = nil
		local tile_down = nil
		local check1 = false
		local check_front = false
		local check_up = false
		local check_down = false

        if steal.type == 2 then
            for i = count, max, 1 do
			
                tile_front = tile:get_tile(facing, i)
                tile_up = tile_front:get_tile(Direction.Up, 1)
                tile_down = tile_front:get_tile(Direction.Down, 1)
                
                check_front = tile_front and team ~= tile_front:get_team() and not tile_front:is_edge() and tile_front:get_team() ~= Team.Other and user:is_team(tile_front:get_tile(Direction.reverse(facing), 1):get_team())
                check_up = tile_up and team ~= tile_up:get_team() and not tile_up:is_edge() and tile_up:get_team() ~= Team.Other and user:is_team(tile_up:get_tile(Direction.reverse(facing), 1):get_team())
                check_down = tile_down and team ~= tile_down:get_team() and not tile_down:is_edge() and tile_down:get_team() ~= Team.Other and user:is_team(tile_down:get_tile(Direction.reverse(facing), 1):get_team())
                
                if check_front or check_up or check_down then
                    table.insert(tile_array, tile_front)
                    table.insert(tile_array, tile_up)
                    table.insert(tile_array, tile_down)
                    break
                end
                print("tile at ("..tile_front:x().."x, "..tile_front:y().."y) has been skipped")
            end
        else
            for i = count, max, 1 do
			
                tile_front = tile:get_tile(facing, i)
                
                check_front = tile_front and team ~= tile_front:get_team() and not tile_front:is_edge() and tile_front:get_team() ~= Team.Other and user:is_team(tile_front:get_tile(Direction.reverse(facing), 1):get_team())
                
                if check_front then
                    table.insert(tile_array, tile_front)
                    break
                end
                print("tile at ("..tile_front:x().."x, "..tile_front:y().."y) has been skipped")
            end
        end
        if #tile_array > 0 and not check1 then
			Engine.play_audio(STEAL_AUDIO1, AudioPriority.High)
			for i = 1, #tile_array, 1 do
				MakeTileSplash(user, team, field, tile_array[i])
			end
			check1 = true
		end
    end
    action.action_end_func = function(self, user)
		actor:set_offset(original_offset.x, original_offset.y)
	end
    return action
end

function MakeTileSplash(user, team, field, tile)
	local artifact = Battle.Artifact.new()
	artifact:sprite():set_texture(STEAL_TEXTURE, true)
	local anim = artifact:get_animation()
	anim:load(STEAL_ANIMPATH)
	anim:set_state("0")
	anim:refresh(artifact:sprite())
    anim:set_playback(Playback.Loop)
	artifact:set_offset(0, -432)
	artifact:sprite():set_layer(-1)
    local hitbox = create_hitbox(user, team)
	local doOnce = false
	artifact.update_func = function(self, dt)
		if self:get_offset().y >= 0 then
			if not doOnce then
				self:set_offset(0, 0)
				self:get_animation():set_state("1")
                self:get_animation():refresh(self:sprite())
                self:get_animation():set_playback(Playback.Once)
				self:get_current_tile():set_team(team, false)
				self:get_animation():on_frame(1, function()
					Engine.play_audio(STEAL_AUDIO2, AudioPriority.High)
				end)
				field:spawn(hitbox, self:get_current_tile())
				doOnce = true
			end
			self:get_animation():on_complete(function()
                hitbox:delete()
				self:delete()
			end)
		else
			self:set_offset(0, self:get_offset().y + (8*2))
		end
	end
	artifact.delete_func = function(self)
		self:erase()
	end
    field:spawn(artifact, tile)
	return artifact
end

function create_hitbox(user, team)
    local spell = Battle.Spell.new(team)
	spell:set_hit_props(
        HitProps.new(
		    10, 
		    Hit.Impact | Hit.Flinch,
		    Element.None,
		    user:get_id(),
		    Drag.None
	    )
    )
    spell.update_func = function(self)
        self:get_current_tile():attack_entities(self)
    end
    spell.attack_func = function(self, ent)
        if Battle.Obstacle.from(ent) == nil then
            --[[
            if Battle.Player.from(user) ~= nil then
                Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
            end
            ]]
        else
            Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
        end
    end
    spell.delete_func = function(self)
        self:erase()
    end
    return spell
end

return steal