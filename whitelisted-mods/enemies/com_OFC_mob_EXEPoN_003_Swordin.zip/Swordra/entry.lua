local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "Swordra",
        hp = 120,
        damage = 60,
        height = 44,
        move_speed = 42,
        element = Element.Fire,
        palette = _folderpath.."V2.png"
    }
    shared_package_init(character, character_info)
end
