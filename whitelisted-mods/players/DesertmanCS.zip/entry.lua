function package_init(package) 
    package:declare_package_id("com.D3str0y3d&Alrysc&Aeon.Desertman")
    package:set_speed(2.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_special_description("Will slip through your fingers")
    package:set_icon_texture(Engine.load_texture(_modpath.."mega_face.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."ow.animation")
    package:set_overworld_texture_path(_modpath.."ow.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
    package:set_mugshot_texture_path(_modpath.."mug.png")
end

local DASH_SFX = Engine.load_audio(_modpath.."dash.ogg")
local SAND_SFX = Engine.load_audio(_modpath.."sand.ogg")
local HIT_SFX = Engine.load_audio(_modpath.."hit.ogg")
local APPEAR_SFX = Engine.load_audio(_modpath.."appear.ogg")
local FLASH_SFX = Engine.load_audio(_modpath.."flash.ogg")

local ATTACK_TEXTURE = Engine.load_texture(_modpath.."battle_fx29_animations.png")

function player_init(player)
    player:set_name("Desertman")
    player:set_health(1000)
    player:set_element(Element.None)
    player:set_height(60)
    player:set_charge_position(0,-14)

    local base_animation_path = _modpath.."battle.animation"
    local base_texture = Engine.load_texture(_modpath.."battle.png")

    player:set_animation(base_animation_path)
    player:set_texture(base_texture)
    player:set_fully_charged_color(Color.new(255, 55, 198, 255))

    player.normal_attack_func = function(player)
        return Battle.Buster.new(player, false, player:get_attack_level())
    end

    player.charged_attack_func = antlion
    player.special_attack_func = desert_mirage

    player.hand = nil
    player.hand_cooldown = 0

    -- Making it a battlestep component instead of being in the update specifically to let it respawn while stunned
    local function make_hand_cooldown_component(player)
        local component = Battle.Component.new(player, Lifetimes.Battlestep)

        component.update_func = function()
            if player.hand then return end

            if player.hand_cooldown == 0 then 
                player.hand = create_hand(player, false, true)
                player.hand_cooldown = 480
                if not player.hand then 
                    player.hand_cooldown = 60
                else
                    player:get_field():notify_on_delete(player.hand:get_id(), player:get_id(), function()
                        player.hand = nil
                    end)
                end
            else
                player.hand_cooldown = player.hand_cooldown - 1
            end
        end
        player:register_component(component)
    end

    local make_special_cooldown_component = function(player)
        local component = Battle.Component.new(player, Lifetimes.Battlestep)
        player.special_cooldown = 0

        component.update_func = function()
            if player.special_cooldown > 0 then 
                player.special_cooldown = player.special_cooldown - 1
            end
        end
        player:register_component(component)
    end

    player.first = true
    player.special_cooldown_max = 600
    -- Attempt to spawn a hand on first frame of battle, then let a component handle that in the future
    player.update_func = function(player)
        if player.first then 
            make_special_cooldown_component(player)

            player.hand = create_hand(player, true, false)
            player.hand_cooldown = 480
            if not player.hand then 
                player.hand_cooldown = 60
            else
                player:get_field():notify_on_delete(player.hand:get_id(), player:get_id(), function()
                    player.hand = nil
                end)
            end

            make_hand_cooldown_component(player)

            player.first = false
        end
    end
end


function desert_mirage(user)
    if user.special_cooldown ~= 0 then return end

    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    action:set_lockout(make_sequence_lockout())

    local step = Battle.Step.new()
    local tower1 = nil
    local tower2 = nil
    step.update_func = function()
        if tower1:is_deleted() then 
            step:complete_step()
        end
    end

    action.execute_func = function(self)
        Engine.play_audio(APPEAR_SFX, AudioPriority.Low)
        tower1 = create_mirage_tower(user, -1, {x = -20, y = 10}, true)
        tower2 = create_mirage_tower(user, 1, {x = 20, y = -20})
        self:add_step(step)
        
    end

    action.action_end_func = function()
        user.special_cooldown = user.special_cooldown_max
        if tower1 and not tower1:is_deleted() then 
            tower1:delete()
            tower1:hide()
        end

        if tower2 and not tower2:is_deleted() then 
            tower2:delete()
            tower2:hide()
        end

    end

    return action
end

function create_mirage_tower(user, layer, offset, should_flash)
    local x_correction = 1
    local facing = user:get_facing()
    if facing == Direction.Left then 
        x_correction = -1
    end

    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(facing)
    spell:set_texture(Engine.load_texture(_modpath.."battle.png"))
    spell:sprite():set_layer(layer)
    spell:set_offset(offset.x * x_correction, offset.y)

    local anim = spell:get_animation()
    anim:load(_modpath.."battle.animation")
    anim:set_state("MIRAGE_TOWER")

    if should_flash then 
        anim:on_frame(10, function()
            screen_flash(user, 4)
            mirage_attack(user)
            Engine.play_audio(FLASH_SFX, AudioPriority.Low)
        end)

        anim:on_frame(11, function()
            screen_flash(user, 4)
        end)
    end

    anim:on_complete(function()
        spell:hide()
        spell:delete()
    end)

    anim:refresh(spell:sprite())

    user:get_field():spawn(spell, user:get_current_tile())
    return spell
end

function mirage_attack(user)
    local team = user:get_team()
    local field = user:get_field()
    local context = user:get_context()

    local function attack(tile)
        local spell = Battle.Spell.new(team)
        spell:set_hit_props(
            HitProps.new(
                0,
                Hit.Blind,
                Element.None,
                context,
                Drag.None
            )
        )

        spell.update_func = function(spell)
            tile:attack_entities(spell)
            spell:delete()
        end

        field:spawn(spell, tile)
    end


    for i=1, field:width()
    do
        for j=1, field:height()
        do
            attack(field:tile_at(i, j))
        end
    end
end

function screen_flash(self, time)
    time = time or 3
    local field = self:get_field()
    local whiteout = Battle.Artifact.new()
    whiteout:set_facing(Direction.Right)
    whiteout:set_texture(Engine.load_texture(_modpath.."white.png"))
    whiteout:sprite():set_layer(99)

    local anim = whiteout:get_animation()
    anim:load(_modpath.."white.animation")
    anim:set_state("WHITEOUT")


    local white = whiteout:sprite()

    white:set_width(2000)
    white:set_height(2000)
    

    white:set_offset(-90, -100)

    anim:refresh(white)

    local lifetime = time
    whiteout.update_func = function(self)
        if lifetime == 0 then 
            self:delete()
            self:hide()
        end

        lifetime = lifetime - 1
    end

    field:spawn(whiteout, field:tile_at(field:width()+1, field:height()+1))

    return whiteout
end



function antlion(user)
    local action = Battle.CardAction.new(user, "PLAYER_IDLE")
    local override_frames = {{1, 0.1}, {1, 0.8}}
    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)

    action.execute_func = function(self)
        self:add_anim_action(2, function()
            sand_vortex_attack(user, find_target_tile(user))
        end)

    end


    return action
end

function find_target_tile(user)
    local field = user:get_field()
    local team = user:get_team()
    local enemies = field:find_nearest_characters(user, function(c)
        return c:get_team() ~= team and  c:get_current_tile():is_walkable()
    end)


    if enemies[1] then 
        return enemies[1]:get_current_tile()
    else
        return get_random_enemy_tile(field, team)
    end
end

function get_random_enemy_tile(field, team)
    local tiles = field:find_tiles(function(t)
        return t:get_team() ~= team
    end)

    if #tiles == 0 then 
        return nil
    else
        return tiles[math.random(#tiles)]
    end
end

function sand_vortex_attack(user, tile)
    if not tile or not tile:is_walkable() then 
        return
    end

    local spell = Battle.Spell.new(user:get_team())
    spell.attacking = false

    spell:set_facing(user:get_facing())
    spell:set_hit_props(
        HitProps.new(
            20 + user:get_attack_level() * 10,
            Hit.Impact | Hit.Flinch | Hit.Root,
            Element.None,
            user:get_context(),
            Drag.None
        )
    )

    local anim = spell:get_animation()
    spell:set_texture(ATTACK_TEXTURE)
    anim:load(_modpath.."battle_fx29_animations.animation")
    anim:set_state("0")
   -- spell:hide()
   -- anim:set_playback_speed(0)

    anim:on_complete(function()
        anim:set_state("1")
        anim:set_playback(Playback.Loop)
        anim:refresh(spell:sprite())
    
        spell.attacking = true
    end)

    anim:refresh(spell:sprite())

    local highlight_time = 0 -- The highlight looks super annoying, but in case it's wanted just raise this
    local attack_time = 40
    spell.update_func = function(self)
        if highlight_time > 0 then 
            self:get_current_tile():highlight(Highlight.Solid)
        end

        highlight_time = highlight_time - 1

        if self.attacking then 
            self:get_current_tile():attack_entities(self)
            attack_time = attack_time - 1
            if attack_time == 0 then 
                self.attacking = false
                anim:set_state("2")
                anim:on_complete(function()
                    self:delete()
                end)
                anim:refresh(self:sprite())
            end
        end

    end

    spell.on_spawn_func = function()
        Engine.play_audio(SAND_SFX, AudioPriority.Low)
    end

    spell.attack_func = function()
        Engine.play_audio(HIT_SFX, AudioPriority.Low)
    end

    user:get_field():spawn(spell, tile)
end

--[[
    Spawns an Obstacle hand object on some front row tile.
    If not_random, attempt spawn on top tile
    If should_spawn_anim, play the spawn animation
        These are true and false respectively for the battle start spawn

    If the hand can't spawn on the chosen tile, it will attempt other random tiles in the front until exhausted

    The hand will wait some frames, and then attempt to follow an enemy. If it lines up with this target at the end of movement, 
    it will attack it by creating a second Obstacle and hiding the hand. These are linked with HP, and one being destroyed will destroy the other

    Returns the hand it made
]]
function create_hand(user, not_random, should_spawn_anim)
    local spawn_tile = nil
    local possible_tiles = get_front_tiles(user)
    local field = user:get_field()
    local hand = Battle.Obstacle.new(user:get_team())
    hand:share_tile(false)
    local hand_id = hand:get_id()
    local has_entity_query = function(c)
        return c:get_id() ~= hand_id and not c:is_deleted() and c:get_health() > 0
    end

    local function can_spawn_on_tile(tile)
        if not tile or tile:is_edge() or not tile:is_walkable() then 
            return false 
        end


        if #tile:find_characters(has_entity_query) > 0 or #tile:find_obstacles(has_entity_query) > 0 then 
          --  print("Has entities, don't go there")
            return false
        end

        return true
    end

    if not_random then 
        spawn_tile = table.remove(possible_tiles, 1)
    else
        spawn_tile = table.remove(possible_tiles, math.random(#possible_tiles))
    end

    if not can_spawn_on_tile(spawn_tile) then 
        for i=1, (field:height()-1) do
            spawn_tile = table.remove(possible_tiles, math.random(#possible_tiles))
            if can_spawn_on_tile(spawn_tile) then 
                break
            end
        end
    end

    if spawn_tile == nil then 
      --  print("Could not spawn hand")
        return nil
    end

    local anim = hand:get_animation()
    field:notify_on_delete(user:get_id(), hand:get_id(), function()
        hand:delete()
    end)
    hand:set_texture(Engine.load_texture(_modpath.."battle.png"))
    hand:set_facing(user:get_facing())
    anim:load(_modpath.."battle.animation")

    if should_spawn_anim then 
        anim:set_state("HAND_RESPAWN")
        anim:on_complete(function()
            anim:set_state("HAND_LOOP")
            anim:set_playback(Playback.Loop)
            anim:refresh(hand:sprite())

        end)
    else
        anim:set_state("HAND_LOOP")
        anim:set_playback(Playback.Loop)
    end

    anim:refresh(hand:sprite())

    hand:set_health(20)
    hand:set_float_shoe(true)
    
    -- Can walk on any tile in its column that is walkable and on the same team
    hand.can_move_to_func = function(t)
        return t:x() == hand:get_tile():x() and t:get_team() == hand:get_team() and can_spawn_on_tile(t)
    end
            
    hand.delete_func = function(self)
        if self:get_health() <= 0 then 
            field:spawn(Battle.Explosion.new(1, 1), self:get_current_tile())
        end
        --  local fade = graphic_init("artifact", 0, 0, "mimaAttack.png", "mima.animation", -2, "SKELETON_DELETE", self, self:get_facing(), true)
        --field:spawn(fade, self:get_current_tile())
    end
    
        
    
    local function choose_move(self)
        local t = self.target:get_tile()

        local dir = Direction.Down

        if t:y() - self:get_tile():y() < 0 then 
            dir = Direction.Up
        end
        
        return self:get_tile(dir, 1)
    end

    local function reset(self)
        anim:set_state("HAND_RESPAWN")
        anim:on_complete(function()
            anim:set_state("HAND_LOOP")
            anim:set_playback(Playback.Loop)
            anim:refresh(self:sprite())
            self.acting = false
            self.wait = self.max_wait
            self.pre_move = false
            self:toggle_hitbox(true)
        end)
        
        anim:refresh(self:sprite())
    end

    local function move(self)
        local t = choose_move(self)
       
        if self.can_move_to_func(t) then 
            self.pre_move = true
            self:slide(t, frames(50), frames(0), ActionOrder.Voluntary, function()
                self.pre_move = false
            end)
        end
       
    end
    
    local function attack(self)
        self.acting = true
        local should_update = false
        self:toggle_hitbox(false)
        self:hide()

        local lion = Battle.Obstacle.new(self:get_team())
        lion:share_tile(true)

        field:notify_on_delete(self:get_id(), lion:get_id(), function()
            lion:delete()
        end)
        lion:set_health(self:get_health())
        lion:set_texture(self:get_texture())
        lion:set_facing(self:get_facing())
        local lion_anim = lion:get_animation()
        lion_anim:load(_modpath.."battle.animation")
        lion_anim:set_state("HAND_ATTACK_START")
        
        lion_anim:on_complete(function()
            lion_anim:set_state("HAND_ATTACK_LOOP")
            should_update = true
            lion_anim:set_playback(Playback.Loop)
            lion_anim:refresh(self:sprite())
        end)

        lion_anim:refresh(lion:sprite())

        lion.can_move_to_func = function()
            return true
        end

        lion.delete_func = function()
            lion:hide()
            if lion:get_health() > 0 then 
                self:set_health(lion:get_health())
                self:reveal()
                reset(self)
            else
                field:spawn(Battle.Explosion.new(1, 1), lion:get_current_tile())

                self:delete()
            end
        end

        local function attack_tile(tile)
            local spell = Battle.Spell.new(lion:get_team())
            spell:set_facing(user:get_facing())
            spell:set_hit_props(
                HitProps.new(
                    user:get_attack_level() * 10,
                    Hit.Impact | Hit.Flinch | Hit.Flash | 2048, -- Hit.NoCounter
                    Element.None,
                    user:get_context(),
                    Drag.None
                )
            )

            spell.on_spawn_func = function(spell)
                tile:attack_entities(spell)
            end
            spell.update_func = function(spell)
                spell:delete()
            end

            spell.attack_func = function()
                Engine.play_audio(HIT_SFX, AudioPriority.Low)
            end
        

            field:spawn(spell, tile)
        end

        local move_wait = 10
        lion.current_tile = nil
        lion.update_func = function(lion)
            if move_wait <= 0 then 
                local tile = lion:get_current_tile()
                local next_tile = tile:get_tile(lion:get_facing(), 1)

                if not next_tile or tile:is_edge() or not tile:is_walkable() then 
                    lion:delete()
                    return
                end
                
                if not lion:is_sliding() then 
                    lion:slide(next_tile, frames(5), frames(0), ActionOrder.Voluntary)
                end

                if lion.current_tile ~= tile then 
                    attack_tile(tile)
                    lion.current_tile = tile
                end
            end

            if move_wait == 0 then 
                Engine.play_audio(DASH_SFX, AudioPriority.Low)
            end

            if should_update then 
                move_wait = move_wait - 1
            end
        end


        field:spawn(lion, self:get_current_tile())

    end
    
    local function target_query(c) 
        return c:get_team() ~= hand:get_team()

    end

    hand.acting = false
    hand.target = (field:find_characters(target_query))[1]

    hand.max_wait = 35
    hand.wait = hand.max_wait
        
    hand.update_component = Battle.Component.new(hand, Lifetimes.Battlestep)

    hand.update_component.update_func = function(self)
        --print("Hand update ")
        if not hand.acting then 
            --print("Wait", hand.wait)
            hand.wait = hand.wait - 1

            if hand.wait <= 0 then 
              --  print("Done waiting")
             --   hand.acting = true
            else
                return
            end
        end

        if hand.wait <= 0 then 
            if not hand.target or hand.target:is_deleted() then 
              --  print("Need to find new target")
                hand.target = (field:find_characters(target_query))[1]
            end

            if not hand.target then 
             --   print("No target found")
                return
            end

            if not hand.pre_move and not hand.acting and not hand:is_sliding() then 
                
                if hand.target:get_tile():y() == hand:get_tile():y() then
                 --   print("Going to attack")
                    attack(hand)
                elseif not hand.acting then
                    move(hand)
                end 
            
            end
        end    
        
        --print("")
    end

    hand:register_component(hand.update_component)


    field:spawn(hand, spawn_tile)
    return hand
end

function get_front_tiles(self, index)
    local team = self:get_team()
    local field = self:get_field()
    local x = field:width()

    local facing = self:get_facing()

    if facing == Direction.Right then 
        x = 1
    end

    local front_tiles = {
        field:tile_at(x, 1),
        field:tile_at(x, 2),
        field:tile_at(x, 3)
    }


    for i=1, 3
    do
        t = front_tiles[i]
        for j=1, field:width()
        do
            t = t:get_tile(facing, 1)
            if t and not t:is_edge() and t:get_team() == self:get_team() then 
                front_tiles[i] = t
            else
                break
            end
        end
    end


    return front_tiles
end