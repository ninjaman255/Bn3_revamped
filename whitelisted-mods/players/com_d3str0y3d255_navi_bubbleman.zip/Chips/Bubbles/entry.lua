nonce = function() end

local bubbles = {}

bubbles.card_create_action = function(user, props)
local action = Battle.CardAction.new(user, "PLAYER_SHOOTING")
	
	action:set_lockout(make_animation_lockout())

    action.execute_func = function(self, user)
			local buster = self:add_attachment("BUSTER")
		buster:sprite():set_texture(Engine.load_texture(_folderpath.."navi_bubbleman_atlas.og.png"), true)
		buster:sprite():set_layer(-1)
		
		local buster_anim = buster:get_animation()
		buster_anim:load(_folderpath.."bubbleman.animation")
		buster_anim:set_state("BUSTER")
	
	
self:add_anim_action(3, function()
	Engine.play_audio(Engine.load_audio(_folderpath.."bubble.ogg"), AudioPriority.High)
		local cannonshot = spawn_bubble(user, props)
		local tile = user:get_tile(user:get_facing(), 1)
		user:get_field():spawn(cannonshot, tile)
		end)
	end
    return action
end

function spawn_bubble(user, props)
    local bubble = Battle.Obstacle.new(user:get_team())
    bubble:set_health(1)
    bubble:set_facing(user:get_facing())
    local direction = bubble:get_facing()
	local bubble_edge = false
    bubble:set_texture(user:get_texture())
    bubble:set_name("bubblebomb")
    local anim = bubble:get_animation()
    anim:copy_from(user:get_animation())
    anim:set_state("BUBBLE_BOMB")
    anim:refresh(bubble:sprite())
    anim:set_playback(Playback.Loop)
    bubble.can_move_to_func = function(tile) return true end
    bubble:set_hit_props(
        HitProps.new(
            0,
            Hit.Impact | Hit.Flash,
            Element.None,
            user:get_context(),
            Drag.None
        )
    )
	
	    local hit_props = HitProps.new(props.damage,
                                   Hit.Impact | Hit.Flinch | Hit.Flash,
                                   Element.Aqua, user:get_context(), Drag.None)
	
    bubble:sprite():set_layer(-1)
    bubble:share_tile(true)
    bubble.slide_started = false
    bubble.collision_func = function(self, other)
	Engine.play_audio(Engine.load_audio(_folderpath.."bubble_pop.ogg"), AudioPriority.High)
	                anim:set_state("BUBBLE_BOMB_POP")
                anim:set_playback(Playback.Once)
                
                anim:on_complete(function()
                            self:delete()
                end)
    end
    local field = user:get_field()
    bubble.delete_func = function(self)
	local target_tile = self:get_tile()
	                    hit_explosion(user, target_tile, hit_props,
                                  Engine.load_texture(_folderpath .. "bubbler.png"), _folderpath .. "bubbler.animation",
                                  Engine.load_audio(_folderpath .. "spout_bubbles.ogg"))
        self:erase()
    end
    local same_column_query = function(c)
        return not c:is_deleted() and c:get_team() ~= bubble:get_team() and c:get_tile():x() == bubble:get_tile():x() and c:get_tile():y() ~= bubble:get_tile():y()
    end
    local has_turned = false
    bubble.update_func = function(self, dt)
        self:get_tile():attack_entities(self)
        if self:get_current_tile():is_edge() and self.slide_started and not self:is_deleted() and not bubble_edge then 
		bubble_edge = true
            	Engine.play_audio(Engine.load_audio(_folderpath.."bubble_pop.ogg"), AudioPriority.High)
	                anim:set_state("BUBBLE_BOMB_POP")
                anim:set_playback(Playback.Once)
                
                anim:on_complete(function()
				bubble_edge = false
                            self:delete()
                end)
        end
        if self:is_deleted() then return end
        if self:is_sliding() == false then
            local dest = self:get_tile(direction, 1)
			if #field:find_characters(same_column_query) > 0 and not has_turned then
                local target = field:find_characters(same_column_query)[1]
                if target:get_tile():y() < self:get_tile():y() then
                    direction = Direction.Up
                else
                    direction = Direction.Down
                end
                dest = self:get_tile(direction, 1)
                has_turned = true
            end
            local ref = self
            self:slide(dest, frames(35), frames(0), ActionOrder.Voluntary, function()
                ref.slide_started = true 
            end)
        end
    end
    bubble.can_move_to_func = function(tile)
        return true
    end
    return bubble
end

function hit_explosion(user, target_tile, props, texture, anim_path, explosion_sound)
    local field = user:get_field()
    local directions = {
		Direction.UpLeft,
		Direction.DownLeft,
		Direction.UpRight,
		Direction.DownRight,
    }

    table.insert(directions, Direction.None)

    for _, dir in ipairs(directions) do
        local adjacent_tile = target_tile:get_tile(dir, 1)
        if adjacent_tile and not adjacent_tile:is_edge() and adjacent_tile:is_walkable() then
            local spell = Battle.Spell.new(user:get_team())
            local spell_animation = spell:get_animation()
            spell_animation:load(anim_path)
            spell_animation:set_state("DEFAULT")
            local sprite = spell:sprite()
            sprite:set_texture(texture)
            spell_animation:refresh(sprite)

            spell_animation:on_complete(function() spell:erase() end)

            spell:set_hit_props(props)
            spell.has_attacked = false
            spell.update_func = function(self)
                if not spell.has_attacked then
                    Engine.play_audio(explosion_sound, AudioPriority.High)
                    spell:get_current_tile():attack_entities(self)
                    spell.has_attacked = true
                end
            end
            field:spawn(spell, adjacent_tile)
        end
    end
end

return bubbles