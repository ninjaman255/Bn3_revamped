local shield = {}

local HIT_SFX = Engine.load_audio(_modpath.."shared/hit.ogg")
local shield_sfx = Engine.load_audio(_folderpath.."shield.ogg")
local tink_sfx = Engine.load_audio(_folderpath.."tink.ogg")

local guard_hit_animation = _folderpath.."guard_hit.animation"
local guard_texture = Engine.load_texture(_folderpath.."guard_hit.png")

shield.init = function(user)
    user.raiment_cooldown = 0
    user.raiment_cooldown_component = Battle.Component.new(user, Lifetimes.Local)

    user.raiment_cooldown_component.update_func = function()
        if user.raiment_cooldown > 0 then 
            user.raiment_cooldown = user.raiment_cooldown - 1
        end
    end

    user:register_component(user.raiment_cooldown_component)

    user.raiment_initialized = true
end

shield.card_create_action = function(user)
    if not user.raiment_initialized then 
        shield.init(user)
    end

    if user.raiment_cooldown > 0 then 
        return
    end
    local action = Battle.CardAction.new(user, "RAIMENT_GUARD")

    action:set_lockout(make_sequence_lockout())
    local guarded = false
    local action_started = false
    local move_dir = nil
    local current_frame = -1 -- Update runs twice on execute for some reason
    local spin_start_frame = 21 + 3 + 1 -- + 1 because grahhhh
    local GUARDING = { 1, 0.35 }
    local POST_GUARDING = { 1, 0.05 }
    local SPIN_1 = {2, 0.033}
    local SPIN_2 = {3, 0.033}
    local SPIN_3 = {4, 0.033}
    local SPIN_4 = {5, 100}

    local FRAMES = make_frame_data({ GUARDING, POST_GUARDING, SPIN_1, SPIN_2, SPIN_3, SPIN_4 })
    action:override_animation_frames(FRAMES)

    action.update_func = function(self)
       
        if(current_frame == spin_start_frame) then 
          --  print("Spin starts this frame")
            return
        end

        if action_started then 
            current_frame = current_frame + 1
        end

        if guarded then 
            local actor = action:get_actor()
            actor:get_animation():update(1/60, actor:sprite())
            action.update_func(self, actor)
        end
    end

    local guard_step = Battle.Step.new()
    guard_step.update_func = function()

    end

    action:add_anim_action(3, function() 
       -- print("Frame 3 callback") 
        if not guarded or move_dir == nil then 
            guard_step:complete_step() 
            action:end_action()
        else
            create_slash(user)
            move_slide(user, move_dir, 12, user:get_animation(), action, function() 
                guard_step:complete_step()
                local c = Battle.Component.new(user, Lifetimes.Battlestep)
                local t = 1
                c.update_func = function()
                    if t == 0 then 
                        user.dest_tile_backup:add_entity(user)
                        user.orig_tile:remove_entity_by_id(user:get_id())
                        c:eject()
                    end
                    t = t - 1
                end
    
                user:register_component(c)
            end)
        end
    end)


    action.execute_func = function(self)
       -- print("Execute")
        action_started = true
        self:add_step(guard_step)

        local guarding = true    

        local guarding_defense_rule = Battle.DefenseRule.new(3, DefenseOrder.CollisionOnly)
        local moving_defense_rule = nil 
        local guard_watch_component = Battle.Component.new(user, Lifetimes.Scene)
        local ejected = false

        guard_watch_component.update_func = function()
            if guarded then 
                user:remove_defense_rule(guarding_defense_rule)
                guarding_defense_rule = nil

                moving_defense_rule = Battle.DefenseRule.new(3, DefenseOrder.Always)
                moving_defense_rule.can_block_func = function(judge)
                    judge:block_damage()
                    judge:block_impact()
                end

                user:add_defense_rule(moving_defense_rule)
                guard_watch_component:eject()
                ejected = true
            end
        end

        user:register_component(guard_watch_component)

       
        local offset = {}
        offset.x = 32
        offset.y = 0

        if user:get_facing() == Direction.Left then 
            offset.x = offset.x * -1
        end

        self:add_anim_action(2, function()
            if guarding_defense_rule then 
                user:remove_defense_rule(guarding_defense_rule)
            end
            guarding = false
        
        end)

        guarding_defense_rule.can_block_func = function(judge, attacker, defender)
            if not guarding or judge:is_damage_blocked() or judge:is_impact_blocked() then
                return
            end

            local attacker_hit_props = attacker:copy_hit_props()

            if attacker_hit_props.damage > 0  and attacker_hit_props.flags & Hit.Impact == Hit.Impact then
                local dirs = {Direction.Up, Direction.Down}
                local dir = dirs[math.random(1, 2)]
                local could_move = user:teleport(user:get_tile(dir, 1), ActionOrder.Immediate, nil)
                if not could_move then 
                    dir = Direction.reverse(dir)
                    could_move = user:teleport(user:get_tile(dir, 1), ActionOrder.Immediate, nil)
                end

                if not could_move then
                    return 
                else
                    move_dir = dir
                end
                judge:block_impact()
                judge:block_damage()
                local direction = user:get_facing()
                
                local tink = Battle.Artifact.new()
                local tink_sprite = tink:sprite()
                tink_sprite:set_texture(guard_texture)
                tink_sprite:set_layer(-3)

                local tink_animation = tink:get_animation()
                tink_animation:load(guard_hit_animation)
                tink_animation:set_state("DEFAULT")

                tink_animation:refresh(tink_sprite)
                tink_animation:on_complete(function()
                    tink:delete()
                end)

                local r = math.random(-10, 10)
                local d = r%2 -- Extra to make sure we stay in actual pixels, not half pixels
                tink:set_offset(offset.x+r+d, -40+r+d)


                user:get_field():spawn(tink, user:get_current_tile())

                Engine.play_audio(tink_sfx, AudioPriority.Low)
                if not guarding_defense_rule.has_reflected then
                    guarding_defense_rule.has_reflected = true
                end

                guarded = true
            end
        end

        user:add_defense_rule(guarding_defense_rule)

        action.action_end_func = function()           
            if not guarded then 
                user.raiment_cooldown = 40
            end

            if guarding and guarding_defense_rule then 
                user:remove_defense_rule(guarding_defense_rule)
                guarding_defense_rule = nil
            end

            if moving_defense_rule then 
                user:remove_defense_rule(moving_defense_rule)
                moving_defense_rule = nil
            end

            if not ejected then 
                guard_watch_component:eject()
                ejected = true
            end
        end
    end

    return action
end

function create_slash(user)
    local tile = user:get_tile(user:get_facing(), 1)
    if not tile or tile:is_edge() then return end

    local spell = Battle.Spell.new(user:get_team())
    spell:set_facing(user:get_facing())
    local sprite = spell:sprite()
    sprite:set_texture(Engine.load_texture(_folderpath.."player_fx0C_animations.png"))
    sprite:set_layer(-1)

    local anim = spell:get_animation()
    anim:load(_folderpath.."player_fx0C_animations.animation")
    anim:set_state("2")
    anim:set_playback_speed(0)

    anim:refresh(sprite)

    local hit_props = HitProps.new(
        50,
        Hit.Impact | Hit.Flinch | 2048,
        Element.None, 
        user:get_context(), 
        Drag.None
    )

    spell:set_hit_props(hit_props)

    spell.update_func = function(self)
        self:get_current_tile():attack_entities(self)
        if self:is_sliding() == false then
            if not self:get_tile(self:get_facing(), 1) and self.slide_started then 
                self:delete()

            end 
            
            local dest = self:get_tile(self:get_facing(), 1)
            local ref = self
            self:slide(dest, frames(6), frames(0), ActionOrder.Voluntary, nil)
        end
    end

    spell.can_move_to_func = function()
        return true
    end

    spell.collision_func = function(self)
        self:delete()
    end

    spell.attack_func = function()
        Engine.play_audio(HIT_SFX, AudioPriority.Low)
    end
    user:get_field():spawn(spell, tile)

end

function move_slide(self, direction, time, anim, action, finish_callback)
    time = time or nil
    self.slide_component = Battle.Component.new(self, Lifetimes.Battlestep)
    local startPosition = 0
    local target = -50
    if direction == Direction.Down then 
        target = target * -1
    end
    local moveTime = 18
    if time then 
        moveTime = time
    end
    local elapsedMoveTime = 0
    local delta = 0

    local interp = 0
    local tileOffset = 0 
    local t = self:get_tile(direction, 1);
    self.slide_dest = t
    self.dest_tile_backup = self.slide_dest
    self.orig_tile = self:get_current_tile()
    t:reserve_entity_by_id(self:get_id())

    local moved = false;
    local already_moved = false;
    
    anim:on_interrupt(function()
        if not self.slide_component then return end
        self.slide_component:eject()
        self.slide_component = nil
        t:add_entity(self)
        self.orig_tile:remove_entity_by_id(self:get_id())
        self:set_offset(0, 0)

    end)

    self.slide_component.update_func = function()
        if delta >= 0.5 and not moved then 
            target = 0
        end
        
        delta = math.max(math.min(elapsedMoveTime, moveTime), 0)/moveTime
        interp =  target * delta + (startPosition * (1 - delta))
        
        tileOffset = interp - startPosition
        if delta >= 0.5 then
            tileOffset = -1*target + startPosition + tileOffset
        end

        if not already_moved then 
            t:reserve_entity_by_id(self:get_id())
        end

        -- Offsets are reflected a frame later than they're set
            -- So this moves us a frame later than we set an offset 
            -- for the new panel
        if moved and not already_moved then 
            already_moved = true
            start_tile = self:get_current_tile()
            start_tile:get_tile(direction, 1):add_entity(self)
            start_tile:remove_entity_by_id(self:get_id())
            self.slide_dest = nil
        end

        if delta >=0.5 and not moved then             
            moved = true

        end

        self:set_offset(0, tileOffset)


        if elapsedMoveTime == moveTime then 
            self.slide_component:eject()
            self.slide_component = nil
            self:set_offset(0, 0)
            finish_callback()

        end

        elapsedMoveTime = elapsedMoveTime + 1

    end


    self:register_component(self.slide_component)

  
end


return shield