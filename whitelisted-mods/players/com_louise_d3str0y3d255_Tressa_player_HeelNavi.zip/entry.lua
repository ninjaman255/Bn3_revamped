local function get_character_id(folder)
    return "com.louise.d3str0y3d255.Tressa.player.HeelNavi" .. folder
end

local function define_character(folder)
    Engine.define_character(get_character_id(folder), _modpath .. "virus/" .. folder)
end

function package_init(package)
    package:declare_package_id("com.louise.d3str0y3d255.Tressa.player.HeelNavi")
    package:set_special_description("It seems that now I am the protagonist")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_icon_texture(Engine.load_texture(_folderpath .. "icon.png"))
    package:set_preview_texture(Engine.load_texture(_folderpath .. "preview.png"))
    package:set_overworld_animation_path(_folderpath .. "ow.animation")
    package:set_overworld_texture_path(_folderpath .. "ow.png")
    package:set_mugshot_texture_path(_folderpath .. "mug.png")
    package:set_mugshot_animation_path(_folderpath .. "mug.animation")
	package:set_emotions_texture_path(_modpath.."emotions.png")	
    define_character("mettaur")
    define_character("canosmart")
    define_character("champy")	
end

function player_init(player)
    player:set_name("HeelNavi")
    player:set_health(1000)
    player:set_element(Element.None)
    player:set_height(50.0)

    local base_texture = Engine.load_texture(_folderpath .. "battle.png")
    local base_animation_path = _folderpath .. "battle.animation"
    local base_charge_color = Color.new(125, 22, 168, 255)

    player:set_animation(base_animation_path)
    player:set_texture(base_texture)
    player:set_fully_charged_color(base_charge_color)
    player:set_charge_position(0, -20)

    player.virusspawn = false
    player.index = math.random(1, 3)

		player.battle_start_func = function(player)
	player.virusspawn = false
    end		

	player.battle_end_func = function(player)
	   player.virusspawn = false
    end

    player.normal_attack_func = function()
        return Battle.Buster.new(player, false, player:get_attack_level())
    end

    player.charged_attack_func = function()
    local props = Battle.CardProperties:new()
    props.damage = (player:get_attack_level() * 10)
    return include("Chips/AirShot/entry.lua").card_create_action(player, props)
    end	

  local virus_array = {"mettaur", "canosmart", "champy"}
  
  local virus_index = 1
  local is_virus_spawned = false

      player.special_attack_func = function()
    local action = Battle.CardAction.new(player, "PLAYER_SUMMON")
    action:set_lockout(make_animation_lockout())
	---------------spawn animation
	        local fx1 = Battle.Artifact.new()
        fx1:set_offset( 0, -25 )
        local explosion_texture = Engine.load_texture(_folderpath .. "Skills/Punk/spawn.png")
        fx1:set_texture(explosion_texture)
        local fx1_anim = fx1:get_animation()
        fx1_anim:load(_folderpath .. "Skills/Punk/spawn.animation")
        fx1_anim:set_state("DEFAULT")
        fx1_anim:refresh(fx1:sprite())
        fx1:sprite():set_layer(-2)
		        fx1_anim:on_complete(function()
            fx1:erase()
        end)
	---------------			
    action.execute_func = function(self, user)
	            if not player.virusspawn then
                Engine.play_audio(Engine.load_audio(_modpath.."Skills/Punk/appearHQ.ogg", true), AudioPriority.High)				
			    user:get_field():spawn(fx1, player:get_tile(player:get_facing(), 1))				
      self:add_anim_action(4, function()
            local tile = player:get_tile(player:get_facing(), 1)
            print(tile)
           if player:is_team(tile:get_team()) then
                print("got into team check")
                local virus_name = virus_array[player.index]
                print("got virus name")
                local virus = Battle.Character.from_package(get_character_id(virus_name), player:get_team(), Rank.V1)
                print("made virus")
                player:get_field():spawn(virus, tile)
                print("spawned virus")
                print("index upped")
                local field = player:get_field()
                field:callback_on_delete(virus:get_id(), function()
                 player.virusspawn = false
---"math.random(1, x)" x = max number of diferent virus					 
                 player.index = math.random(1, 3)
	     		 print("Drawn number:", player.index)
                 end)
                 player.virusspawn = true
                print("done")
                  end
              end)
			  else
			    player:get_animation():set_state("CHEER")
                Engine.play_audio(Engine.load_audio(_modpath.."Skills/Punk/Denied.ogg", true), AudioPriority.High)				  
           end
		end
        return action
    end
	
end
