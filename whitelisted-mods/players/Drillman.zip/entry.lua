local drill = include("Chips/Drill/entry.lua")

function package_init(package)
    package:declare_package_id("navi.D3str0y3d255&Tressa")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_special_description("time to make some holes")	
	package:set_icon_texture(Engine.load_texture(_modpath.."pet.png"))	
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."DrillmanOW.animation")
    package:set_overworld_texture_path(_modpath.."DrillmanOW.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
    package:set_mugshot_texture_path(_modpath.."mug.png")
	package:set_emotions_texture_path(_modpath.."emotions.png")	
end

function player_init(player)
    player:set_name("Drillman")
    player:set_health(1000)
    player:set_element(Element.Break)
    player:set_height(75.0)
    player:set_animation(_modpath.."Drillman.animation")
    player:set_texture(Engine.load_texture(_modpath.."navi_drillman_atlas.og.png"), true)
    player:set_fully_charged_color(Color.new(224, 112, 32, 0))
    player:set_charge_position(4, -25)
	player.normal_attack_func = create_normal_attack
    player.charged_attack_func = create_charged_attack 
	player.special_attack_func = create_special_attack
end

function create_special_attack(player)
    if Battle.Player.from(player).charged_attack_func == create_charged_attack then
		player:set_fully_charged_color(Color.new(198, 198, 198, 0))
        player.charged_attack_func = create_charged_attack2
	
    elseif Battle.Player.from(player).charged_attack_func == create_charged_attack2 then
	player:set_fully_charged_color(Color.new(224, 112, 32, 0))
        player.charged_attack_func = create_charged_attack
		
    end
end

function create_normal_attack(player)
return Battle.Buster.new(player, false, player:get_attack_level())
end

function create_charged_attack(player)
        local props = Battle.CardProperties:new()
		props.damage = (player:get_attack_level() * 10)
        return drill.card_create_action(player, props)
end

    function create_charged_attack2(player)
	    local dark_query = function(o)
        return Battle.Obstacle.from(o) ~= nil and o:get_health() > 0
    end 	
	        local facing = player:get_facing()
        local field = player:get_field()
        local team = player:get_team()

        local self_tile = player:get_current_tile()
        local self_X = self_tile:x()
        local self_Y = self_tile:y()

        local team_check = function(ent)
            if not player:is_team(ent:get_team()) then
                return true
            end
        end
	
	
        local targeted = false
        local tile1_check = false
        local tile2_check = false
        local tile_array1 = {}
        local desired_tile
		
		       if facing == Direction.Right then
            for i = 1, 6, 1 do
                for j = 1, 3, 1 do
                    if i > self_X then
                        if not targeted then
                            local tile1 = field:tile_at(i,j)
                            local tile2 = tile1:get_tile(Direction.reverse(facing), 1)
                            tile1_check = tile1 and tile1 ~= nil and #tile1:find_characters(team_check) > 0
                        tile2_check = tile2 and tile2 ~= nil and not tile2:is_edge() and #tile2:find_characters(team_check) <= 0 and #tile2:find_entities(dark_query) <= 0
                            if tile1_check and tile2_check then
                                print("target found at tile ("..i..";"..j..")")
                                table.insert(tile_array1, tile1)
                                desired_tile = tile_array1[1]:get_tile(Direction.reverse(facing), 0)
                                targeted = true
                                break
                            end
                        end
                    end
                end
            end
        else
            for i = 6, 1, -1 do
                for j = 1, 3, 1 do
                    if i < self_X then
                        if not targeted then
                            local tile1 = field:tile_at(i,j)
                            local tile2 = tile1:get_tile(Direction.reverse(facing), 0)
                            tile1_check = tile1 and tile1 ~= nil and #tile1:find_characters(team_check) > 0
                        tile2_check = tile2 and tile2 ~= nil and not tile2:is_edge() and #tile2:find_characters(team_check) <= 0 and #tile2:find_entities(dark_query) <= 0
                            if tile1_check and tile2_check then
                                print("target found at tile ("..i..";"..j..")")
                                table.insert(tile_array1, tile1)
                                desired_tile = tile_array1[1]:get_tile(Direction.reverse(facing), 0)
                                targeted = true
                                break
                            end
                        end
                    end
                end
            end
        end
		
		
		
        local original_tile = player:get_tile()
        local is_occupied = function(query)
            return query and not query:is_deleted() and Battle.Character.from(query) ~= nil or query and not query:is_deleted() and Battle.Obstacle.from(query) ~= nil
        end
                if targeted then
            local action = Battle.CardAction.new(player, "PLAYER_DRILLUP")
            action.can_move_to_func = function(tile)
                return true
            end
            action:set_lockout(make_animation_lockout())
            local props = HitProps.new(
                (player:get_attack_level() * 10) + 50,
                Hit.Impact | Hit.Flinch | Hit.Flash,
                Element.Break,
                player:get_context(),
                Drag.None
            )
            action.action_end_func = function(self)
                desired_tile:remove_entity_by_id(player:get_id())
                original_tile:remove_entity_by_id(player:get_id())
                original_tile:add_entity(player)
				player:toggle_hitbox(true)
            end
            action.execute_func = function(self, user)
						self:add_anim_action(1,	function()
						Engine.play_audio(Engine.load_audio(_modpath.."Chips/Drillup/Up.ogg"), AudioPriority.High)
			end)
			
			
			self:add_anim_action(24,	function()
								player:toggle_hitbox(false)
                desired_tile:add_entity(player)
				end)
							self:add_anim_action(26,	function()
						    Engine.play_audio(Engine.load_audio(_modpath.."Chips/Drillup/Uphole.ogg"), AudioPriority.High)

				end)
				
                self:add_anim_action(26,	function()
                    local sword = create_slash(user, props)
                    local tile = user:get_tile(user:get_facing(), 0)
                    local sharebox1 = Battle.SharedHitbox.new(sword, 0.15)
                    sharebox1:set_hit_props(sword:copy_hit_props())
                    local sharebox2 = Battle.SharedHitbox.new(sword, 0.15)
                    sharebox2:set_hit_props(sword:copy_hit_props())
                    player:get_field():spawn(sword, tile)
                    local fx = Battle.Artifact.new()
                    fx:set_facing(sword:get_facing())
                    local anim = fx:get_animation()
                    fx:set_texture(Engine.load_texture(_modpath.."Chips/Drillup/spell_sword_slashes.png"), true)
                    anim:load(_modpath.."Chips/Drillup/spell_sword_slashes.animation")
                    anim:set_state("WIDE")
                    anim:on_complete(function()
                        fx:erase()
                        sword:erase()
						drop_rocks(user, 3, 29)
                    end)
                    player:get_field():spawn(fx, tile)
                end)
            end
		    return action
        else
								Engine.play_audio(Engine.load_audio(_modpath.."Chips/Drillup/Up.ogg"), AudioPriority.High)
            return Battle.CardAction.new(player, "PLAYER_CHARGED_FAIL")
        end
    end
	
	function create_slash(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			Element.Break,
			user:get_context(),
			Drag.None
		)
	)

	spell.update_func = function(self, dt) 
		self:get_tile():attack_entities(self)
    if self:get_tile():get_state() == TileState.Cracked then
        self:get_tile():set_state(TileState.Broken)
    else
        self:get_tile():set_state(TileState.Cracked)
       end
	end

        spell.collision_func = function(self)
        Engine.play_audio(Engine.load_audio(_modpath.."Chips/Drillup/hit.ogg"), AudioPriority.Low)
		
        end


	spell.can_move_to_func = function(tile)
		return true
	end
	return spell
end

function drop_rocks(user, num_rocks, delay)
    if num_rocks <= 0 then return end
    local team = user:get_team()
    local field = user:get_field()

    local spell = Battle.Spell.new(team)
    local tile1 = nil
    local tile2 = nil
    local counter1 = 13
    local counter2 = 26

    local spawn_tiles = {}

    local tile_filter = function(tile)
        return not tile:is_edge() and tile:get_team() ~= team
    end
    local enemy_filter = function(character)
        return character:get_team() ~= team
    end

    local tile_list = field:find_tiles(tile_filter)
    
    local enemy_list = field:find_nearest_characters(user, enemy_filter)

    -- First spawn tile should target an enemy
    if enemy_list[1] then 
        spawn_tiles[1] = enemy_list[1]:get_current_tile()
    else
        spawn_tiles[1] = tile_list[math.random(1, #tile_list)]
    end

    local props = HitProps.new(
        30,
        Hit.Impact | Hit.Flinch | Hit.Flash | Hit.Breaking,
        Element.Break, 
        user:get_context(),
        Drag.None
    )

    -- Allow possible duplicate roll, but do not spawn them
    for i=1, num_rocks-1
    do
        local t = tile_list[math.random(1, #tile_list)]
        local not_dupe = true
        for _k, v in ipairs(spawn_tiles)
        do
            if t == v then 
                not_dupe = false
                break
            end
        end

        if not_dupe then 
            table.insert(spawn_tiles, t)
        end
    end


    spell.update_func = function(self)
        if delay <= 0 then 
            for i=1, #spawn_tiles
            do
                -- User could be deleted by the time this happens. The spell has the same team and facing, so it's good here
                create_rock(self, spawn_tiles[i], props)
            end
            self:delete()
        end
       
        delay = delay - 1
    end

    field:spawn(spell, 0, 0)
end

-- Hits on 27, appears on the top of screen on 5 when at bottom row, flashes for 12-14 before shadow appears?
function create_rock(user, target_tile, props)
    local field = user:get_field()

    local rock = graphic_init("spell", 0, 0, Engine.load_texture(_folderpath.."Chips/Drillup/rock.png"), "Chips/Drillup/rock.animation", -1, "0", user, user:get_facing())
    
    local speed = 6
    local time = 0
    local initial_height = 332
   -- local acceleration = initial_height/(fall_time*fall_time)
    rock:set_elevation(speed*72)
    rock:show_shadow(true)
    rock:set_shadow(1)

    rock:set_hit_props(props)

    local function rock_break(tile)
        Engine.play_audio(Engine.load_audio(_folderpath.."Chips/Drillup/rockbreak.ogg"), AudioPriority.High)

        local piece1 = graphic_init("artifact", 0, 0, Engine.load_texture(_folderpath.."Chips/Drillup/rock.png"), "Chips/Drillup/rock.animation", -2, "1", rock, rock:get_facing())
        piece1.time = -6
        piece1.flash_count = 0
        piece1:show_shadow(true)
        piece1:set_shadow(1)
        local piece2 = graphic_init("artifact", 0, 0, Engine.load_texture(_folderpath.."Chips/Drillup/rock.png"), "Chips/Drillup/rock.animation", -2, "1", rock, rock:get_facing())
        piece2.time = -8
        piece2.flash_count = 0
        piece2:show_shadow(true)
        piece2:set_shadow(1)


        piece1.update_func = function(self)
            local time = self.time
            if self:get_elevation() >= 0 then 

                self:set_offset(self:get_offset().x + 4, 0)
                self:set_elevation(-1*(time*time)/2 + 20)
                
            else
                if time % 4 < 2 then
                    self:hide()
                    if self.flash_count > 3 then 
                        self:delete()
                    end
                else
                    self:reveal()
                    self.flash_count = self.flash_count + 1
                end 
                
            end
            
            self.time = self.time+1

        end

        piece2.update_func = function(self)
            local time = self.time
            if self:get_elevation() >= 0 then 

                self:set_offset(self:get_offset().x - 2, 0)
                self:set_elevation(-1*(time*time)/3 + 30)
                
            else
                if time % 4 < 2 then
                    self:hide()
                    if self.flash_count > 3 then 
                        self:delete()
                    end
                else
                    self:reveal()
                    self.flash_count = self.flash_count + 1
                end 
                
            end

            self.time = self.time+1


        end

        field:spawn(piece1, tile)
        field:spawn(piece2, tile)
    end

    rock.broken = false
    rock.update_func = function(self)
        local elev = self:get_elevation()
        local t = self:get_current_tile()
        if elev <= 60 then 
            t:attack_entities(self)
    
        end

        if self:get_elevation() <= 0 then 
            if t:is_walkable() then 
                rock_break(t)
            else
                local hit_effect = graphic_init("artifact", 0, 0, Engine.load_texture(_folderpath.."Chips/Drillup/move.png"), "move.animation", -3, "0", self, self:get_facing(), true)
                self:get_field():spawn(hit_effect, t)
            end
            
            self:delete()

            return
        end

        self:set_elevation(self:get_elevation() - speed)

        time = time + 1
    end

    -- I'm pretty sure we'll end up breaking twice somewhere, but I might've covered it
    rock.collision_func = function(self, other)
        if not self.broken then 
            rock_break(self:get_current_tile())
        end
        if not self:is_deleted() then 
            self:delete()
        end
    end

    rock.attack_func = function(self, other)
        local o = get_random_offset()
        local hit_effect = graphic_init("artifact", o.x, o.y, Engine.load_texture(_folderpath.."Chips/Drillup/overlay_fx05_animations.png"), "overlay_fx05_animations.animation", -3, "1", self, self:get_facing(), true)
        self:get_field():spawn(hit_effect, other:get_current_tile())

        Engine.play_audio(Engine.load_audio(_modpath.."Chips/Drillup/hit.ogg"), AudioPriority.Low)
    end

    field:spawn(rock, target_tile)
end

function get_random_offset()
    local x = math.random(0, 40)
    local y = math.random(10, 40)
    
    x = x - 20
    y = y * -1

    return {x = x, y = y}
end

function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
    flip = flip or false
    delete_on_complete = delete_on_complete or false
    facing = facing or nil
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()

    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())

    end

    graphic:sprite():set_layer(layer)
    graphic:never_flip(flip)
    graphic:set_texture(texture, false)
    if facing then 
        graphic:set_facing(facing)
    end
    
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    anim:load(_folderpath..animation)

    anim:set_state(state)
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end