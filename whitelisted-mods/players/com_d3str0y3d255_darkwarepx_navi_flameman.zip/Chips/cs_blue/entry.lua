local DAMAGE = 80

local TEXTURE_FLAME = Engine.load_texture(_folderpath.."flame.png")
local ANIMPATH_FLAME = _folderpath.."flame.animation"
local AUDIO_SPAWN = Engine.load_audio(_folderpath.."spawn.ogg")
local AUDIO_HEATWAVE = Engine.load_audio(_folderpath.."heatwave.ogg")

local TEXTURE_EFFECT = Engine.load_texture(_folderpath.."effect.png")
local ANIMPATH_EFFECT = _folderpath.."effect.animation"
local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."hitsound.ogg")


local bluecharge = {}

bluecharge.card_create_action = function(actor, props)
    local action = Battle.CardAction.new(actor, "PLAYER_CS2")
	action:set_lockout(make_animation_lockout())
    action.execute_func = function(self, user)
	
	local field = actor:get_field()
	local direction = user:get_facing()
	    local self_tile = user:get_tile()
		
        local X = self_tile:x()
        local Y = self_tile:y()

                local flamehit1 = create_flame(user, props)
                local flamehit2 = create_flame(user, props)
                local flamehit3 = create_flame(user, props)
                local flamehit4 = create_flame(user, props)


		self:add_anim_action(4, function()
                   Engine.play_audio(AUDIO_HEATWAVE, AudioPriority.Low)
                    if direction == Direction.Right then
                        field:spawn(flamehit3, X + 2, 2)

                        if Y == 1 then
                            field:spawn(flamehit1, X + 1, 1)
                            field:spawn(flamehit2, X + 2, 1)
                        elseif Y == 2 then
                            field:spawn(flamehit1, X + 1, 2)
                            field:spawn(flamehit2, X + 2, 1)
                            field:spawn(flamehit4, X + 2, 3)
                        else
                            field:spawn(flamehit1, X + 1, 3)
                            field:spawn(flamehit4, X + 2, 3)
                        end
                    else
                        field:spawn(flamehit3, X - 2, 2)

                        if Y == 1 then
                            field:spawn(flamehit1, X - 1, 1)
                            field:spawn(flamehit2, X - 2, 1)
                        elseif Y == 2 then
                            field:spawn(flamehit1, X - 1, 2)
                            field:spawn(flamehit2, X - 2, 1)
                            field:spawn(flamehit4, X - 2, 3)
                        else
                            field:spawn(flamehit1, X - 1, 3)
                            field:spawn(flamehit4, X - 2, 3)
                        end
                    end
			end)
			
	end
    return action
end

function create_flame(actor, props)

    local field = actor:get_field()
    local spell = Battle.Spell.new(actor:get_team())
    local spellanim = spell:get_animation()
    local direction = actor:get_facing()
    spell:set_facing(direction)
    spell:set_texture(TEXTURE_FLAME, true)
    spellanim:load(ANIMPATH_FLAME)
    spellanim:set_state("DEFAULT")
    spellanim:refresh(spell:sprite())
    spellanim:on_complete(function()
        spell:erase()
    end)
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flash | Hit.Flinch,
            Element.Fire,
            actor:get_id(),
            Drag.None
        )
    )

     spell.update_func = function(self, dt)
        local current_tile = self:get_current_tile()
        if not current_tile or not current_tile:is_walkable() then
            self:erase() -- Remova o feitiço se o tile não for andável
            return
        end
		
		if self:get_tile():get_state() ~= TileState.Ice then
		self:get_tile():set_state( TileState.Ice ) 
		end
		
        current_tile:attack_entities(self)
    end

    spell.can_move_to_func = function(tile)
        return tile:is_walkable()
    end

    spell.battle_end_func = function(self)
		spell:erase()
	end

    spell.attack_func = function()
        Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
        local hitfx = Battle.Artifact.new()
		hitfx:set_facing(Direction.Right)
		local hitfxanim = hitfx:get_animation()
		hitfx:set_texture(TEXTURE_EFFECT, true)
		hitfxanim:load(ANIMPATH_EFFECT)
		hitfxanim:set_state("DEFAULT")
        hitfxanim:refresh(hitfx:sprite())
        hitfxanim:on_complete(function()
            hitfx:erase()
        end)
        field:spawn(hitfx, spell:get_current_tile())
    end

    return spell
end

return bluecharge