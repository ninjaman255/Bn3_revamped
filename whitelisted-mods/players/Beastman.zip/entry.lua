local beastslash = include("Chips/BeastSlash/entry.lua")
local slash = include("Chips/Slash/entry.lua")

function package_init(package)
    package:declare_package_id("com.D3stroy3d&Vide&DarkWarePX.player.Beastman")
    package:set_special_description("Uncage your inner beast!")
    package:set_speed(3.0)
    package:set_attack(1)
    package:set_charged_attack(90)
    package:set_icon_texture(Engine.load_texture(_modpath.."beastman_face.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."ow.animation")
    package:set_overworld_texture_path(_modpath.."ow.png")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
    package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("Beastman")
    player:set_health(1000)
    player:set_element(Element.None)
    player:set_height (60.0)
    player:set_charge_position(1,-14)
    player:set_animation(_modpath.."beastman.animation")
    player:set_texture(Engine.load_texture(_modpath.."beastman.png"), true)
    player:set_fully_charged_color(Color.new(255, 165, 0, 255))
    player.normal_attack_func = create_normal_attack
    player.charged_attack_func = create_charged_attack
    player.special_attack_func = create_special_attack 
end

function create_charged_attack(player)
        local props = Battle.CardProperties:new()
        props.damage = 10 + (player:get_attack_level() * 10)
        return beastslash.card_create_action(player, props)
end

function create_charged_attack2(player)
        local props = Battle.CardProperties:new()
        props.damage = 65 + (player:get_attack_level() * 35)
        return slash.card_create_action(player, props)
end

function create_normal_attack(player)
    return Battle.Buster.new(player, false, player:get_attack_level() * 1)
end

function create_special_attack(player)
    if Battle.Player.from(player).charged_attack_func == create_charged_attack then
        player.charged_attack_func = create_charged_attack2
		player:set_fully_charged_color(Color.new(154,91,81,255))
    elseif Battle.Player.from(player).charged_attack_func == create_charged_attack2 then
        player.charged_attack_func = create_charged_attack
		player:set_fully_charged_color(Color.new(255, 165, 0, 255))
    end
end

