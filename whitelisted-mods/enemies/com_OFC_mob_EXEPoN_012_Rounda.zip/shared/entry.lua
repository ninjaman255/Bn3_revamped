local AUDIO_DAMAGE = Engine.load_audio(_folderpath.."EXE4_270.ogg")
local AUDIO_DAMAGE_OBS = Engine.load_audio(_folderpath.."EXE4_221.ogg")

local CHARACTER_TEXTURE = Engine.load_texture(_folderpath.."battle.grayscaled.png")
local CHARACTER_ANIMATION = _folderpath.."battle.animation"
local BOOMERANG_TEXTURE = Engine.load_texture(_folderpath.."boomerang.png")
local BOOMERANG_ANIMPATH = _folderpath.."boomerang.animation"
local BOOMERANG_AUDIO = Engine.load_audio(_folderpath.."EXE4_143.ogg")

local EFFECT_TEXTURE = Engine.load_texture(_folderpath.."effect.png")
local EFFECT_ANIMPATH = _folderpath.."effect.animation"
local GUARD_TEXTURE = Engine.load_texture(_folderpath.."guard_hit.png")
local GUARD_ANIMPATH = _folderpath.."guard_hit.animation"
local GUARD_AUDIO = Engine.load_audio(_folderpath.."EXE4_49.ogg")

--possible states for character
local states = { IDLE = 1, MOVE = 2, WAIT = 3 }
---@param self Entity
function package_init(self, character_info)
    -- Required function, main package information
    -- Load extra resources
    local base_animation_path = CHARACTER_ANIMATION
    self:set_texture(CHARACTER_TEXTURE)
    self.animation = self:get_animation()
    self.animation:load(base_animation_path)

    -- Set up character meta
    self:set_name(character_info.name)
    self:set_health(character_info.hp)
    self:set_height(character_info.height)
    self.damage = character_info.damage
    self:share_tile(false)
    self:set_explosion_behavior(3, 1, false)
    self:set_offset(0, 0)
    self:set_palette(Engine.load_texture(character_info.palette))
    self.panelgrabs = character_info.panelgrabs
    self.boomerang_speed = character_info.boomerang_speed
    self.animation:set_state("SPAWN")
    self.frame_counter = 0
    self.started = false
    self.idle_frames = 45
    --Select Boomer move direction
    self.move_direction = Direction.Up
    self.move_speed = character_info.move_speed
    --self.defense = Battle.DefenseVirusBody.new()
    --self:add_defense_rule(self.defense)
    self.reached_edge = false
    self.has_attacked_once = false
    self.guard = true
    self.end_wait = false

    self.delay_before_turn = false
    self.delay_counter = 0

    self:set_air_shoe(true)
    self:set_float_shoe(true)

    self.defense_rule = Battle.DefenseRule.new(0, DefenseOrder.Always)
    self.defense_rule.can_block_func = function(judge, attacker, defender)
        local attacker_hit_props = attacker:copy_hit_props()

        if (self.guard) then

            if attacker_hit_props.flags & Hit.Breaking == Hit.Breaking then
                --cant block breaking hits
                return
            end
            judge:block_impact()
            judge:block_damage()
            Engine.play_audio(GUARD_AUDIO, AudioPriority.Low)
            create_effect(self:get_facing(), GUARD_TEXTURE, GUARD_ANIMPATH, "DEFAULT", math.random(-20,20), math.random(-20,20), true, -999999, self:get_field(), self:get_current_tile())
        end
    end
    self:add_defense_rule(self.defense_rule)

    ---state idle
    ---@param frame number
    self.action_idle = function(frame)
        if (frame == self.idle_frames) then
            ---choose move direction.
            self.animation:set_state("IDLE")
            self.animation:set_playback(Playback.Loop)
            self.end_wait = false
            self.turn()
        end
    end

    self.turn = function()
        self.move_direction = Direction.reverse(self.move_direction)

        self.set_state(states.MOVE)
    end

    self.update_func = function()
        if self.delay_before_turn then
            print("delay before turn")
            self.delay_counter = self.delay_counter + 1
            if self.delay_counter >= 30 then
                self.delay_counter = 0
                self.delay_before_turn = false
                if self:get_current_tile():y() == 2 then
                    self.turn()
                else
                    self.reached_edge = true
                end
            end
        end
    end

    ---state move
    ---@param frame number
    self.action_move = function(frame)
        if (frame == 1) then
            local target_tile = self:get_tile(self.move_direction, 1)
            if (not is_tile_free_for_movement(target_tile, self)) then
                if (target_tile:is_edge()) then
                    self.reached_edge = true
                else
                    if (not is_tile_free_for_movement(self:get_tile(Direction.Up, 1), self) and
                        not is_tile_free_for_movement(self:get_tile(Direction.Down, 1), self)) then
                        --detect if stuck
                        if self:get_current_tile():y() == 2 then
                            self.reached_edge = false
                        else
                            self.reached_edge = true
                        end
                    else
                        self.turn()
                    end
                end
            end
            self:slide(target_tile, frames(self.move_speed), frames(0), ActionOrder.Immediate, nil)
        end
        if (frame > 2 and not self:is_sliding()) then
            if self.reached_edge then
                -- if at the edge(or stuck), throw boomerang
                self.throw_boomerang()
                self.set_state(states.WAIT)
                self.reached_edge = false
            else
                -- keep moving to edge.
                self.set_state(states.MOVE)
                self.reached_edge = false
            end

        end
    end

    ---state wait
    ---@param frame number
    self.action_wait = function(frame)
        if (not self.end_wait) then
            self.wait_frame_counter = 0
        end
        self.wait_frame_counter = self.wait_frame_counter + 1
        if (self.wait_frame_counter == 60) then
            self.animation:set_state("RECOVER")
            self.set_state(states.IDLE)
            self.guard = true
        end
    end

    --utility to set the update state, and reset frame counter
    ---@param state number
    self.set_state = function(state)
        self.state = state
        self.frame_counter = 0
    end

    local actions = { [1] = self.action_idle, [2] = self.action_move, [3] = self.action_wait }

    self.update_func = function()
        self.frame_counter = self.frame_counter + 1
        if not self.started then
            --- this runs once the battle is started
            self.current_direction = self:get_facing()
            self.started = true
            self.set_state(states.IDLE)

        else
            --- On every frame, we will call the state action func.
            local action_func = actions[self.state]
            action_func(self.frame_counter)
        end
    end

    self.throw_boomerang = function()
        self.animation:set_state("THROW")
        self.has_attacked_once = true
        self.animation:on_frame(3, function()
            self.guard = false
        end)
        self.animation:on_complete(function()
            create_boomerang(self, self:get_tile(self:get_facing(), 1))

            self.set_state(states.WAIT)
            self.animation:set_state("WAIT")
            self.animation:set_playback(Playback.Loop)
            self.end_wait = false
        end)
    end

    function Tiletostring(tile)
        return "Tile: [" .. tostring(tile:x()) .. "," .. tostring(tile:y()) .. "]"
    end
end

---Checks if the tile in 2 given directions is free and returns that direction
function get_free_direction(tile, direction1, direction2)
    if (not tile:get_tile(direction1, 1):is_edge()) then
        return direction1
    else return direction2

    end
end

function is_tile_free_for_movement(tile, character)
    --Basic check to see if a tile is suitable for a chracter of a team to move to

    if tile:get_team() ~= character:get_team() then
        return false
    end
    if (tile:is_edge()) then
        return false
    end
    local occupants = tile:find_entities(function(ent)
        if (Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil) then
            return true
        else
            return false
        end
    end)
    if #occupants == 1 and occupants[1]:get_id() == character:get_id() then
        return true
    end
    if #occupants > 0 then
        return false
    end

    return true
end

function is_tile_free_for_movement_edge_reason(tile, character)
    --Basic check to see if a tile is suitable for a chracter of a team to move to

    if tile:get_team() ~= character:get_team() then
        return true
    end
    if (tile:is_edge()) then
        return true
    end
    local occupants = tile:find_entities(function(ent)
        if (Battle.Character.from(ent) ~= nil or Battle.Obstacle.from(ent) ~= nil) then
            return true
        else
            return false
        end
    end)
    if #occupants == 1 and occupants[1]:get_id() == character:get_id() then
        return true
    end
    if #occupants > 0 then
        return false
    end

    return true
end

function create_boomerang(user, tile)
    local team = user:get_team()
    local field = user:get_field()
    local facing = user:get_facing()
    local spawn_y = tile:y()

    local spell = Battle.Spell.new(team)
    spell:set_hit_props(
        HitProps.new(
            user.damage,
            Hit.Impact | Hit.Flinch,
            Element.Wood,
            user:get_id(),
            Drag.None
        )
    )
    spell:set_facing(facing)
    spell:set_texture(BOOMERANG_TEXTURE, true)
    spell:set_offset(0, -14)
    --spell:highlight_tile(Highlight.Solid)
    local anim = spell:get_animation()
    anim:load(BOOMERANG_ANIMPATH)
    anim:set_state("DEFAULT")
    anim:set_playback(Playback.Loop)
    spell.slide_started = false
    spell.state = 0
    spell.update_func = function(self, dt)
        self:get_current_tile():attack_entities(self)
        if not self:is_sliding() then
            local direction = self:get_tile(facing, 1)
            local is_at = self:get_current_tile()
            local ref = self
            if      spawn_y == 1 then       -- If spawned on TOP

                if facing == Direction.Right then
                    if is_at == field:tile_at(0,3) then
                        --ref:delete()
                    end
                    if is_at == field:tile_at(6,1) and ref.state == 0 then
                        ref.state = 1
                    elseif is_at == field:tile_at(6,3) and ref.state == 1 then
                        ref.state = 2
                    end
                else
                    if is_at == field:tile_at(7,3) then
                        --ref:delete()
                    end
                    if is_at == field:tile_at(1,1) and ref.state == 0 then
                        ref.state = 1
                    elseif is_at == field:tile_at(1,3) and ref.state == 1 then
                        ref.state = 2
                    end
                end
                if ref.state == 1 then
                    direction = self:get_tile(Direction.Down, 1)
                elseif ref.state == 2 then
                    direction = self:get_tile(Direction.reverse(facing), 1)
                else
                    direction = self:get_tile(facing, 1)
                end

            elseif  spawn_y == 2 then       -- IF spawned on MIDDLE

                direction = self:get_tile(facing, 1)
                if facing == Direction.Right then
                    if is_at == field:tile_at(0,2) then
                        --ref:delete()
                    end
                else
                    if is_at == field:tile_at(7,2) then
                        --ref:delete()
                    end
                end

            elseif  spawn_y == 3 then       -- IF spawned on BOTTOM

                if facing == Direction.Right then
                    if is_at == field:tile_at(0,1) then
                        --ref:delete()
                    end
                    if is_at == field:tile_at(6,3) and ref.state == 0 then
                        ref.state = 1
                    elseif is_at == field:tile_at(6,1) and ref.state == 1 then
                        ref.state = 2
                    end
                else
                    if is_at == field:tile_at(7,1) then
                        --ref:delete()
                    end
                    if is_at == field:tile_at(1,3) and ref.state == 0 then
                        ref.state = 1
                    elseif is_at == field:tile_at(1,1) and ref.state == 1 then
                        ref.state = 2
                    end
                end
                if ref.state == 1 then
                    direction = self:get_tile(Direction.Up, 1)
                elseif ref.state == 2 then
                    direction = self:get_tile(Direction.reverse(facing), 1)
                else
                    direction = self:get_tile(facing, 1)
                end

            end

            if is_at:is_edge() then
                self:delete()
            end
            self:slide(direction, frames(user.boomerang_speed), frames(0), ActionOrder.Voluntary, 
            function()
                ref.slide_started = true
            end)
        end
    end
    spell.on_spawn_func = function()
        Engine.play_audio(BOOMERANG_AUDIO, AudioPriority.Low)
    end
    spell.attack_func = function(self, ent)
		create_effect(facing, EFFECT_TEXTURE, EFFECT_ANIMPATH, "5", math.random(-30,30), math.random(-50,-30), true, -999999, field, ent:get_current_tile())
        if Battle.Obstacle.from(ent) == nil then
			--[[
            if Battle.Player.from(user) ~= nil then
				Engine.play_audio(AUDIO_DAMAGE, AudioPriority.Low)
			end
            ]]
		else
			Engine.play_audio(AUDIO_DAMAGE_OBS, AudioPriority.Low)
		end
	end
    spell.delete_func = function()
        if not user:is_deleted() then
            user.animation:on_complete(function()
                user.end_wait = true
            end)
        end
    end
    spell.can_move_to_func = function(tile)
        return true
    end
    field:spawn(spell, tile)
    return spell
end

function create_effect(effect_facing, effect_texture, effect_animpath, effect_state, offset_x, offset_y, flip, offset_layer, field, tile)
    local hitfx = Battle.Artifact.new()
    hitfx:set_facing(effect_facing)
    hitfx:set_texture(effect_texture, true)
    hitfx:set_offset(offset_x, offset_y)
    hitfx:never_flip(flip)
    local hitfx_sprite = hitfx:sprite()
    hitfx_sprite:set_layer(offset_layer)
    local hitfx_anim = hitfx:get_animation()
	hitfx_anim:load(effect_animpath)
	hitfx_anim:set_state(effect_state)
	hitfx_anim:refresh(hitfx_sprite)
    hitfx_anim:on_complete(function()
        hitfx:erase()
    end)
    field:spawn(hitfx, tile)

    return hitfx
end

return package_init