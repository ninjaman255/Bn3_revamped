local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "Garuedan",
        hp = 140,
        damage = 70,
        height = 54,
        move_before_attack = 5,
        current_moves = 5,
        cascade_frame_index = 5,
        shot_type = 3,
        palette = _folderpath.."battle_v3.palette.png"
    }
    shared_package_init(character, character_info)
end
