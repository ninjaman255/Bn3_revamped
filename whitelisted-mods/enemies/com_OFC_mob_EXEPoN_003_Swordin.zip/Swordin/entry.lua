local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "Swordin",
        hp = 70,
        damage = 30,
        height = 44,
        move_speed = 52,
        element = Element.None,
        palette = _folderpath.."V1.png"
    }
    if character:get_rank() == Rank.SP then
        character_info.hp = 240
        character_info.damage = 120
        character_info.move_speed = 16
        character_info.palette = _folderpath.."SP.png"
    end
    shared_package_init(character, character_info)
end
