local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "Swortar",
        hp = 160,
        damage = 100,
        height = 44,
        move_speed = 32,
        element = Element.Aqua,
        palette = _folderpath.."V3.png"
    }
    shared_package_init(character, character_info)
end
