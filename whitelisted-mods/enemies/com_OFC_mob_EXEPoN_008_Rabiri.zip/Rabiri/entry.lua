local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "Rabiri",
        hp = 40,
        damage = 10,
        palette = _folderpath.."battle_v1.palette.png",
        height = 44,
        ring_speed = 4,
        frames_between_actions = 34,
        fast_hop_frames = 4,
        move_ver = 1
    }
    if character:get_rank() == Rank.SP then
        character_info.hp = 200
        character_info.damage = 90
        character_info.palette = _folderpath.."battle_sp.palette.png"
        character_info.ring_speed = 2
        character_info.frames_between_actions = 14
        character_info.move_ver = 4
    end
    shared_package_init(character, character_info)
end
