function package_init(package)
    package:declare_package_id("com.alrysc.player.gutsman")
    package:set_special_description("Fight with Guts!")
    package:set_speed(1.0)
    package:set_attack(5)
    package:set_charged_attack(150)
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."overworld.animation")
    package:set_overworld_texture_path(_modpath.."overworld.png")
    package:set_mugshot_texture_path(_modpath.."mug.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
end

function player_init(player)
    player:set_name("GutsMan")
    player:set_health(1000)
    player:set_element(Element.None)
    player:set_height(55.0)
    player:set_attack_level(1)
    player:set_charge_level(1)

    local base_texture = Engine.load_texture(_modpath.."battle.png")
    local base_animation_path = _modpath.."battle.animation"

    player:set_animation(base_animation_path)
    player:set_texture(base_texture, true)
    player:set_charge_position(0, -20)

    player.normal_attack_func = include("GutsMachineGun/entry.lua")
    player.charged_attack_func = include("CS/entry.lua")
end





