local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "HiRabiri",
        hp = 80,
        damage = 30,
        palette = _folderpath.."battle_v2.palette.png",
        height = 44,
        ring_speed = 3,
        frames_between_actions = 26,
        fast_hop_frames = 4,
        move_ver = 2
    }
    shared_package_init(character, character_info)
end
