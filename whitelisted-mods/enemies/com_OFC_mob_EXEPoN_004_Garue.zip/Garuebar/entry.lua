local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "Garuebar",
        hp = 100,
        damage = 40,
        height = 54,
        move_before_attack = 6,
        current_moves = 6,
        cascade_frame_index = 10,
        shot_type = 2,
        palette = _folderpath.."battle_v2.palette.png"
    }
    shared_package_init(character, character_info)
end
