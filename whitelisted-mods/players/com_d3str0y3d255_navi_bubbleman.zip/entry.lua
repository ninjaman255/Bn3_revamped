function package_init(package) 
    package:declare_package_id("com.d3str0y3d255.navi.bubbleman")
    package:set_speed(1.0)
	package:set_attack(1)
	package:set_charged_attack(10)
    package:set_special_description("I'm very afraid of the Needle Man")
	package:set_icon_texture(Engine.load_texture(_modpath.."pet.png"))
	package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."overworld.animation")
    package:set_overworld_texture_path(_modpath.."overworld.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
	package:set_mugshot_texture_path(_modpath.."mug.png")
	package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("Bubbleman")
	player:set_health(1000)
	player:set_element(Element.Aqua)
    player:set_height(48.0)
	player:set_charge_position(1,-14)
    player:set_animation(_modpath.."bubbleman.animation")
    player:set_texture(Engine.load_texture(_modpath.."navi_bubbleman_atlas.og.png"), false)
    player:set_fully_charged_color(Color.new(152, 160, 208, 255))
    player.normal_attack_func = create_normal_attack
    player.charged_attack_func = create_charged_attack
	player.special_attack_func = create_special_attack	
	
	player.battle_start_func = function(player)
	Engine.play_audio(Engine.load_audio(_folderpath.."Chips/BubbleWrap/bubble.ogg"), AudioPriority.Low)
    create_barrier(player)			
    end		
	
end

function create_normal_attack(player)
    return Battle.Buster.new(player, false, player:get_attack_level())
end

function create_charged_attack(player)
        local props = Battle.CardProperties:new()
		props.damage = (player:get_attack_level() * 10)		
        return include("Chips/Bubbles/entry.lua").card_create_action(player, props)
end

function create_charged_attack2(player)
        local props = Battle.CardProperties:new()
		props.damage = 5 + (player:get_attack_level() * 10)		
        return include("Chips/Harpoon/charge.lua").card_create_action(player, props)
end

function create_special_attack(player)
    if Battle.Player.from(player).charged_attack_func == create_charged_attack then
		player:set_fully_charged_color(Color.new(240, 232, 240, 0))
        player.charged_attack_func = create_charged_attack2
	
    elseif Battle.Player.from(player).charged_attack_func == create_charged_attack2 then
	player:set_fully_charged_color(Color.new(152, 160, 208, 255))
        player.charged_attack_func = create_charged_attack
		
    end
end

function prepare_node(player, barrier, barrier_animation)
    barrier:set_layer(3)
    barrier:set_texture(Engine.load_texture(_folderpath.."Chips/BubbleWrap/player_fx20_animations.png") , false)

    barrier_animation:set_state("0")
    barrier_animation:refresh(barrier)
   
	barrier:set_offset(0, -1/2*player:get_height())
	
    barrier_animation:set_playback(Playback.Loop)
end

function create_barrier(player, actor)

    player.fading = false
    player.isWind = false
	player.popBack = false
	player.remove_barrier = false

    local barrier = player:create_node()
    local HP = 1

    local barrier_animation = Engine.Animation.new(_folderpath.."Chips/BubbleWrap/player_fx20_animations.animation" )
    prepare_node(player, barrier, barrier_animation)

    if actor then 
        prepare_node(player, actor:create_node(), barrier_animation)
    end
    

    local barrier_defense_rule = Battle.DefenseRule.new(1, DefenseOrder.Always) -- Keristero's Guard is 0
	local barrier_heal_ratelimit = 238

    barrier_defense_rule.can_block_func = function(judge, attacker, defender)
        if HP == 0 then 
            return
        end
        local attacker_hit_props = attacker:copy_hit_props()
        
		if attacker_hit_props.element == Element.Elec then
					HP = 0
			barrier_heal_ratelimit = 238
            return
		elseif attacker_hit_props.element == Element.Wind then
		    HP = 0
			barrier_heal_ratelimit = 238			
			player.isWind = true
		end

		if attacker_hit_props.flags & Hit.Impact == Hit.Impact and HP > 0 then
			HP = 0
			barrier_heal_ratelimit = 238
		end

        judge:block_damage()
    end
	
	local barrier_heal_component = Battle.Component.new(player, Lifetimes.Battlestep)
	barrier_heal_component.update_func = function(self, dt)
        if player:is_deleted() or player:get_health() == 0 then return end

		if barrier_heal_ratelimit <= 0 and HP <= 0 then
			player.popBack = true
			HP = 1
			player.fading = false
			player.remove_barrier = false
		else
			barrier_heal_ratelimit = barrier_heal_ratelimit - 1
		end
	end
	
    local aura_animate_component = Battle.Component.new(player, Lifetimes.Scene)
	
	aura_animate_component.update_func = function(self, dt)
        if player:is_deleted() or player:get_health() == 0 then return end

		barrier_animation:update(dt, barrier)
		if player.popBack then
			player.popBack = false
			Engine.play_audio(Engine.load_audio(_folderpath.."Chips/BubbleWrap/bubble.ogg"), AudioPriority.Low)
			barrier_animation:set_state("0")
			barrier_animation:set_playback(Playback.Loop)
			
		end
	end
	
	local aura_destroy_component = Battle.Component.new(player, Lifetimes.Scene)
	aura_destroy_component.update_func = function(self, dt)
        if player:is_deleted() or player:get_health() == 0 then return end
		
        if HP <= 0 and not player.fading then
            player.remove_barrier = true
        end
        
        if barrier_defense_rule:is_replaced() then
			player:sprite():remove_node(barrier)
			player:remove_defense_rule(barrier_defense_rule)
			aura_destroy_component:eject()
			barrier_heal_component:eject()
			aura_animate_component:eject()
        end
		
		if player.remove_barrier and not player.fading then
			player.fading = true

            if not player.isWind then 
                Engine.play_audio(Engine.load_audio(_folderpath.."Chips/BubbleWrap/bubble_pop.ogg"), AudioPriority.Low)
                barrier_animation:set_state("1")
                barrier_animation:refresh(barrier)
                barrier_animation:set_playback(Playback.Once)
                
                barrier_animation:on_complete(function()
                    barrier_heal_ratelimit = 238
                end)
			elseif	player.isWind then 
			                Engine.play_audio(Engine.load_audio(_folderpath.."Chips/BubbleWrap/bubble_pop.ogg"), AudioPriority.Low)
                barrier_animation:set_state("BLOW_AWAY")
                barrier_animation:refresh(barrier)
                barrier_animation:set_playback(Playback.Once)
                player.isWind = false
                barrier_animation:on_complete(function()
                    barrier_heal_ratelimit = 238
                end)
            end

			
		end
	end
	
    player:add_defense_rule(barrier_defense_rule)
	player:register_component(barrier_heal_component)
	player:register_component(aura_destroy_component)
	player:register_component(aura_animate_component)
end