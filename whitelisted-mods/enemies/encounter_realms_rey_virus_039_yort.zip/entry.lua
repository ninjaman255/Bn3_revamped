local id={}
id.pk="encounter.realms.rey.virus.039.yort"
-- Modified from com.louise.Yort
id.en="mob.realms.rey.virus.039.yort"
-- Modified from com.louise.enemy.Yort

function package_requires_scripts()
	Engine.define_character(id.en,_modpath.."mob")
end

function package_init(package)
	package:declare_package_id(id.pk)
	package:set_name("Yort")
	package:set_description("Rey Realms\u{0027} version.\nSupports ranks!\nEleven ranks of Yeet!!")
	package:set_speed(1)
	package:set_attack(30)
	package:set_health(120)
	package:set_preview_texture_path(_modpath.."package/preview.png")
end

--[[

Eleven ranks of Yeet!!

Rank.NM			-	Yeet
(Rank.NM+1)		- 	Yeet2
(Rank.NM+2)		- 	Yeet3
...				-	...
(Rank.NM+9)		- 	Yeet10
(Rank.NM+10)	- 	YeetX
(Rank.NM+11)	- 	YeetX (still)
(Rank.NM+12)	- 	YeetX (still)
(Rank.NM+13)	- 	YeetX (it's not even getting any stronger, you can stop now.)
(Rank.NM+14)	- 	YeetX (...)
(Rank.NM+15)	- 	YeetX (...)
(Rank.NM+16)	- 	YeetX (...)
...				- 	YeetX (...)

]]

function package_build(mob)

	mob
		:spawn_player(1,2,2)

	mob
		:create_spawner(id.en,Rank.V1)
			:spawn_at(5,2)

end
