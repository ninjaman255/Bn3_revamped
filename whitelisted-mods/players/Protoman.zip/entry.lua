function package_init(package) 
    package:declare_package_id("com.darkware.navi.protoman")
    package:set_speed(1.0)
	package:set_attack(1)
	package:set_charged_attack(10)
    package:set_special_description("I usually don't need an operator")
	package:set_icon_texture(Engine.load_texture(_modpath.."pet.png"))
	package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."overworld.animation")
    package:set_overworld_texture_path(_modpath.."overworld.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
	package:set_mugshot_texture_path(_modpath.."mug.png")
	package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("Protoman")
	player:set_health(1000)
	player:set_element(Element.None)
    player:set_height(48.0)
	player:set_charge_position(4,-17)
    player:set_animation(_modpath.."protoman.animation")
    player:set_texture(Engine.load_texture(_modpath.."navi_protoman_atlas.og.png"), false)
    player:set_fully_charged_color(Color.new(243, 57, 198, 255))
    player.normal_attack_func = create_normal_attack
    player.charged_attack_func = create_charged_attack
    player.special_attack_func = create_special_attack 

player.battle_start_func = function(player)
if  player.styleskin ~= nil then
    local action = Battle.CardAction.new(player, "PLAYER_IDLE")
action:override_animation_frames(make_frame_data({{1, 1.4}, {1, 0.1}}))
action:set_lockout(make_animation_lockout())

                    local meta = action:copy_metadata()
                    meta.time_freeze = true
                    meta.skip_time_freeze_intro = true
                    meta.shortname = "Style Change"
                    action:set_metadata(meta)

-----texture based in player.styleskin value
local style_textures = {
    [1] = Engine.load_texture(_modpath.."styles/aquabody/aquabody.png"),
    [2] = Engine.load_texture(_modpath.."styles/elecbody/elecbody.png"),
    [3] = Engine.load_texture(_modpath.."styles/heatbody/heatbody.png"),
    [4] = Engine.load_texture(_modpath.."styles/woodbody/woodbody.png"),
    [32] = Engine.load_texture(_modpath.."styles/murasamabody/murasamabody.png"),		
}

-- texture variable
local texture_path = style_textures[player.styleskin] or Engine.load_texture(_folderpath .. "navi_protoman_atlas.og.png")
local original_color = player:get_color()

    action.execute_func = function(self, player)

self:add_anim_action(2, function()
    Engine.play_audio(AudioType.Shine, AudioPriority.Low)
player:set_color(Color.new( 255, 255, 255, 255 ))
    player:set_texture(texture_path, true)
player:get_animation():refresh(player:sprite())
end)

    end

    action.animation_end_func = function()
player:set_color(original_color)
    end
    player:card_action_event(action, ActionOrder.Immediate)
end
    end
	
end

function create_normal_attack(player)
    return Battle.Buster.new(player, false, player:get_attack_level())
end

function create_charged_attack(player)
        local props = Battle.CardProperties:new()
        props.damage = 70 + (player:get_attack_level() * 10)
        return include("Chips/Sword/entry.lua").card_create_action(player, props)
end

function create_special_attack(player)
        local props = Battle.CardProperties:new()
        return include("Chips/Shield/entry.lua").card_create_action(player, props)
end