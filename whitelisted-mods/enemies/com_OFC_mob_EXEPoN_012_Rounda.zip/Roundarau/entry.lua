local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "Roundara",
        hp = 100,
        damage = 40,
        palette = _folderpath.."palette.png",
        height = 44,
        frames_between_actions = 78,
        boomerang_speed = 6,
        move_speed = 60,
    }
    shared_package_init(character, character_info)
end