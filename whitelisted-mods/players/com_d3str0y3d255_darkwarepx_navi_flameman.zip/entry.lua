function package_init(package) 
    package:declare_package_id("com.d3str0y3d255&darkwarepx.navi.flameman")
    package:set_speed(1.0)
	package:set_attack(1)
	package:set_charged_attack(10)
    package:set_special_description("fire and chaos is all i leave behind")
	package:set_icon_texture(Engine.load_texture(_modpath.."pet.png"))
	package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."overworld.animation")
    package:set_overworld_texture_path(_modpath.."overworld.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
	package:set_mugshot_texture_path(_modpath.."mug.png")
	package:set_emotions_texture_path(_modpath.."emotions.png")
end

function player_init(player)
    player:set_name("Flameman")
	player:set_health(1000)
	player:set_element(Element.Fire)
    player:set_height(58.0)
	player:set_charge_position(1,-27)
    player:set_animation(_modpath.."flameman.animation")
    player:set_texture(Engine.load_texture(_modpath.."navi_flameman_atlas.og.png"), false)
    player:set_fully_charged_color(Color.new(248, 232, 40, 255))
    player.normal_attack_func = create_normal_attack
    player.charged_attack_func = create_charged_attack

    player.candle_spawned = false
    player.candle_deletecheck = false	
	player.candle_status = 0 --- -1 = wealer flame (no flame) ,0 = no effect (weak flame), 1 = base cs damage boost (Orange Flame), 2 = ice fire cs (blue flame), 3 = burn effect cs (purple flame), 4 = nil value (the value should be 4 ONLY when the candle finishes acquiring a color)
	
	    player.update_func = function()		
		if player.candle_deletecheck and not  player.candle.spawned then
		summon_candle(player)	
		end
	    if not  player.candle_spawned and player.special_attack_func == nil  then
            player.special_attack_func = summon_candle 
        elseif player.special_attack_func == nil then
            player.special_attack_func = create_void
        end	
	end			  
		player.battle_start_func = function(player)     
		summon_candle(player)
        create_tiles(player)		
    end		   
end

function create_normal_attack(player)
    return Battle.Buster.new(player, false, player:get_attack_level())
end

function create_void(player)

end

function create_charged_attack(player)
        local props = Battle.CardProperties:new()
		props.damage = (player:get_attack_level() * 10)
        return include("Chips/Flame/entry.lua").card_create_action(player, props)
end

function create_charged_attack_blue(player)
        local props = Battle.CardProperties:new()
		props.damage = (player:get_attack_level() * 10)
        return include("Chips/cs_blue/entry.lua").card_create_action(player, props)
end

function create_charged_attack_orange(player)
        local props = Battle.CardProperties:new()
		props.damage = (player:get_attack_level() * 20)
        return include("Chips/cs_orange/entry.lua").card_create_action(player, props)
end

function create_charged_attack_purple(player)
        local props = Battle.CardProperties:new()
		props.damage = (player:get_attack_level() * 5)
        return include("Chips/cs_purple/entry.lua").card_create_action(player, props)
end

function summon_candle(player)
				local query = function(ent)
	if (Battle.Obstacle.from(ent) ~= nil and ent:get_name() ~= "Candle Summon") and (Battle.Obstacle.from(ent) ~= nil and ent:get_name() ~= "Candle Summon2") or Battle.Character.from(ent) ~= nil then
						return true
					end
				end

                    player.candle = Battle.Obstacle.new(Team.Other)	
                    player.candle2 = Battle.Obstacle.new(Team.Other)	

					player.candle.framecount = 0
					player.candle.delayframes = 500
				
					local animation = player.candle:get_animation()					
					animation:load(_modpath.."Candle/candles.animation")				
					animation:set_state("SPAWN")									
					player.candle:set_health(9999)
					
					player.candle:set_name("Candle Summon")					
-------------------------------------
					local animation2 = player.candle2:get_animation()					
					animation2:load(_modpath.."Candle/candles.animation")				
					animation2:set_state("SPAWN")									
					player.candle2:set_health(9999)					
					player.candle2:set_name("Candle Summon2")					
-------------------------------------							
animation:on_frame(1, function()
		Engine.play_audio(Engine.load_audio(_folderpath.."Candle/sfx.ogg"), AudioPriority.High)
			        player.candle:set_texture(Engine.load_texture(_modpath.."Candle/candles.png"))
		            player.candle:sprite():set_layer(-3)					
					player.candle:set_facing(player:get_facing())				
        end, true)

animation2:on_frame(1, function()
		Engine.play_audio(Engine.load_audio(_folderpath.."Candle/sfx.ogg"), AudioPriority.High)
			        player.candle2:set_texture(Engine.load_texture(_modpath.."Candle/candles.png"))	
					player.candle2:sprite():set_layer(-3)
					player.candle2:set_facing(player:get_facing())				
        end, true)


				player.candle.defense_rule = Battle.DefenseRule.new(0, DefenseOrder.Always)
                player.candle.defense_rule.can_block_func = function(judge, attacker, defender)
                local attacker_hit_props = attacker:copy_hit_props()

			if attacker_hit_props.element == Element.Wind and player.candle.framecount >= 0 and attacker_hit_props.damage > 0 then
						animation:set_state("IDLE")
						animation2:set_state("IDLE")
animation:refresh(player.candle:sprite())
animation2:refresh(player.candle2:sprite())						
						if Battle.Player.from(player).charged_attack_func == create_charged_attack_blue	or Battle.Player.from(player).charged_attack_func == create_charged_attack_orange or Battle.Player.from(player).charged_attack_func == create_charged_attack_purple then
                        player.charged_attack_func = create_charged_attack	
                        player:set_fully_charged_color(Color.new(248, 232, 40, 255))						
						end						
                        player.candle_status = 0
					    player.candle.framecount = 0						
						animation:set_playback(Playback.Loop)
						animation2:set_playback(Playback.Loop)
			end
			
			if attacker_hit_props.element == Element.Aqua then
						animation:set_state("IDLE_WEAK")
						animation2:set_state("IDLE_WEAK")
animation:refresh(player.candle:sprite())
animation2:refresh(player.candle2:sprite())						if Battle.Player.from(player).charged_attack_func == create_charged_attack_blue	or Battle.Player.from(player).charged_attack_func == create_charged_attack_orange or Battle.Player.from(player).charged_attack_func == create_charged_attack_purple then
                        player.charged_attack_func = create_charged_attack
                        player:set_fully_charged_color(Color.new(248, 232, 40, 255))						
						end							
                        player.candle_status = -1
					    player.candle.framecount = -500						
						animation:set_playback(Playback.Loop)
						animation2:set_playback(Playback.Loop)
			end			

			if attacker_hit_props.element == Element.Fire and player.candle.framecount < 500 then
					    player.candle.framecount = player.candle.framecount + 500						
			end	
			
        end					
					
                    player:add_defense_rule(player.candle.defense_rule)						
					animation:on_complete(function()
						animation:set_state("IDLE")
						animation:set_playback(Playback.Loop)

					end)
					
					animation2:on_complete(function()
						animation2:set_state("IDLE")
						animation2:set_playback(Playback.Loop)

					end)
					
				    player.candle.update_func = function(self, dt)
                    player.candle:toggle_hitbox(false)	
                    player.candle2:toggle_hitbox(false)						
					------candle health and deletion code
                     if player.candle:get_health() < 9999 then
					    player.candle:set_health(9999)
					   end 

                     if player.candle2:get_health() < 9999 then
					    player.candle2:set_health(9999)
					   end 					   
					   
					------candle animations and states code
					if player.candle_status < -1 or player.candle_status > 4 and player.candle_status == 0 then
					player.candle_status = math.random(1, 3)			
					   end

					if player.candle_status == -1 then
					player.candle.framecount = player.candle.framecount + 1
					if player.candle.framecount >= 0 then
						animation:set_state("IDLE")
						animation2:set_state("IDLE")
                        player.candle_status = 0					
						animation:set_playback(Playback.Loop)
						animation2:set_playback(Playback.Loop)
					      end
					   end
					   
					if player.candle_status == 0 then
					player.candle.framecount = player.candle.framecount + 1
					if player.candle.framecount >= player.candle.delayframes then
					player.candle_status = math.random(1, 3)
					player.candle.framecount = 0
					      end
					   end
					
                    if player.candle_status == 1 then
						animation:set_state("ORANGE_GROWN")
						animation2:set_state("ORANGE_GROWN")
animation:refresh(player.candle:sprite())
animation2:refresh(player.candle2:sprite())						
                        player.candle_status = 4
					animation:on_complete(function()
						animation:set_state("IDLE_ORANGE")
animation:refresh(player.candle:sprite())					
						if Battle.Player.from(player).charged_attack_func == create_charged_attack then
                        player.charged_attack_func = create_charged_attack_orange
						player:set_fully_charged_color(Color.new(240, 88, 0, 255))						
						end											
						animation:set_playback(Playback.Loop)
						
					end)

					animation2:on_complete(function()
						animation2:set_state("IDLE_ORANGE")
animation2:refresh(player.candle2:sprite())						
						if Battle.Player.from(player).charged_attack_func == create_charged_attack then
                        player.charged_attack_func = create_charged_attack_orange
						player:set_fully_charged_color(Color.new(240, 88, 0, 255))						
						end											
						animation2:set_playback(Playback.Loop)
						
					end)
					
					   end

                    if player.candle_status == 2 then
						animation:set_state("BLUE_GROWN")
						animation2:set_state("BLUE_GROWN")	
animation:refresh(player.candle:sprite())
animation2:refresh(player.candle2:sprite())						
                        player.candle_status = 4
					animation:on_complete(function()
						animation:set_state("IDLE_BLUE")
animation:refresh(player.candle:sprite())						
						if Battle.Player.from(player).charged_attack_func == create_charged_attack then
                        player.charged_attack_func = create_charged_attack_blue
                        player:set_fully_charged_color(Color.new(0, 144, 255, 255))						
						end
						animation:set_playback(Playback.Loop)
						
					end)

					animation2:on_complete(function()
						animation2:set_state("IDLE_BLUE")
animation2:refresh(player.candle2:sprite())						
						if Battle.Player.from(player).charged_attack_func == create_charged_attack then
                        player.charged_attack_func = create_charged_attack_blue
                        player:set_fully_charged_color(Color.new(0, 144, 255, 255))						
						end
						animation2:set_playback(Playback.Loop)
						
					end)	
					
					   end
					
                    if player.candle_status == 3 then
						animation:set_state("PURPLE_GROWN")	
						animation2:set_state("PURPLE_GROWN")
animation:refresh(player.candle:sprite())
animation2:refresh(player.candle2:sprite())						
                        player.candle_status = 4
					animation:on_complete(function()
						animation:set_state("IDLE_PURPLE")
animation:refresh(player.candle:sprite())						
						if Battle.Player.from(player).charged_attack_func == create_charged_attack then
                        player.charged_attack_func = create_charged_attack_purple
                        player:set_fully_charged_color(Color.new(227, 128, 240, 255))						
						end						
						animation:set_playback(Playback.Loop)
						
					end)

					animation2:on_complete(function()
						animation2:set_state("IDLE_PURPLE")
animation2:refresh(player.candle2:sprite())						
						animation2:set_playback(Playback.Loop)
						
					end)
					
					   end										
					end
					
		            player.candle.delete_func = function(self)
					animation:set_state("DELETE")
					animation2:set_state("DELETE")
					player:remove_defense_rule(player.candle.defense_rule)
					  player.candle_deletecheck  = true
					   player.candle_spawned = false
					   player.candle_status = 0
					  self:erase()
					  player.candle2:erase()
					end
					
					player.candle.can_move_to_func = function(self, tile)			
						return false				
					end	

					player.candle2.can_move_to_func = function(self, tile)			
						return false				
					end	
									
					if player:get_facing() == Direction.Left then
					player:get_field():spawn(player.candle, player:get_field():tile_at(1, 0))
					player:get_field():spawn(player.candle2, player:get_field():tile_at(1, 4))					
                      player.candle_spawned = true
					 player.candle_deletecheck = false			 
                    else
					 player:get_field():spawn(player.candle, player:get_field():tile_at(6, 0))	
					 player:get_field():spawn(player.candle2, player:get_field():tile_at(6, 4))					 
                     player.candle_spawned = true
					 player.candle_deletecheck = false
                        end		 
                  end		  
				  
function create_tiles(player)
local fx = Battle.Artifact.new()
local fx2 = Battle.Artifact.new()

			fx:set_facing(player:get_facing())
			local anim = fx:get_animation()
			anim:load(_folderpath.."Candle/candles.animation")

			fx2:set_facing(player:get_facing())
			local anim2 = fx2:get_animation()
			anim2:load(_folderpath.."Candle/candles.animation")
			
			if player:get_facing() == Direction.Left then
			anim:set_state("BLUE_TILE")
			anim2:set_state("BLUE_TILE")			
			anim:set_playback(Playback.Loop)
			anim2:set_playback(Playback.Loop)			
			player:get_field():spawn(fx, player:get_field():tile_at(1, 0))			
			player:get_field():spawn(fx2, player:get_field():tile_at(1, 4))				
			else
			anim:set_state("RED_TILE")
			anim2:set_state("RED_TILE")			
			anim:set_playback(Playback.Loop)
			anim2:set_playback(Playback.Loop)			
			player:get_field():spawn(fx, player:get_field():tile_at(6, 0))
			player:get_field():spawn(fx2, player:get_field():tile_at(6, 4))				
			end
			
			anim:on_frame(1, function()
			fx:set_texture(Engine.load_texture(_folderpath.."Candle/candles.png"), true)
        end, true)

			anim2:on_frame(1, function()
			fx2:set_texture(Engine.load_texture(_folderpath.."Candle/candles.png"), true)
        end, true)		
		
end				  