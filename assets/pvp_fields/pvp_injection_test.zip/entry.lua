local package_id = "hoov.package.targetdummy"
local character_id = "hoov.enemy.targetdummy"

local ObstacleInfo = include("ObstacleInfo.lua")

function package_requires_scripts()
    Engine.define_character(character_id, _modpath.."targetdummy")
end

function package_init(package)
    package:declare_package_id(package_id)
    package:set_name("Targetdummies")
    package:set_description("Use to test Battle Chips")
    -- package:set_speed(999)
    -- package:set_attack(999)
    -- package:set_health(9999)
    package:set_preview_texture_path(_modpath.."preview.png")
end

function package_build(mob)
    mob:get_field():tile_at(3, 1):set_state(TileState.Lava)
    mob:get_field():tile_at(4, 3):set_state(TileState.Lava)
    mob:get_field():tile_at(2, 1):set_state(TileState.Holy)
    mob:get_field():tile_at(2, 2):set_state(TileState.Holy)
    mob:get_field():tile_at(2, 3):set_state(TileState.Holy)
    mob:get_field():tile_at(5, 1):set_state(TileState.Holy)
    mob:get_field():tile_at(5, 2):set_state(TileState.Holy)
    mob:get_field():tile_at(5, 3):set_state(TileState.Holy)

    --make_metalcube(mob, 3, 1)
    --make_metalcube(mob, 4, 3)
    mob:spawn_player(1, 1, 1)
    mob:spawn_player(2, math.floor(mob:get_field():width()), math.floor(mob:get_field():height()))

    --[[
    mob
        :create_spawner(character_id, Rank.V1)
        :spawn_at(4, 1)
    mob
        :create_spawner(character_id, Rank.V1)
        :spawn_at(5, 2)

    mob
        :create_spawner(character_id, Rank.V1)
        :spawn_at(6, 3)
        ]]

    mob:set_background(_modpath.."BG.png", _modpath.."BG.animation", 0.09, 0.08)
    mob:stream_music(_modpath.."iego-training.ogg", 2812, 65814)
end

function make_metalcube(mob, x, y)
	local metal_defense_rule = Battle.DefenseRule.new(0, DefenseOrder.Always)
    --[[
	metal_defense_rule.can_block_func = function(judge, attacker, defender)
		local attacker_hit_props = attacker:copy_hit_props()
		if attacker_hit_props.damage > 0 then
			judge:block_damage()
		end
	end
    ]]
    metal_defense_rule.filter_statuses_func = function(hit_props)
        hit_props.damage = 0
        hit_props.flags = Hit.None
        hit_props.element = Element.None
        return hit_props
    end
	local metalcube_texture = Engine.load_texture(_folderpath.."metalcube/metalcube.png")
	local metalcube_animation = _folderpath.."metalcube/metalcube.animation"
	local cube = Battle.Obstacle.new(Team.Other)
	ObstacleInfo.set_cannot_be_targeted(cube, false)
    ObstacleInfo.set_cannot_be_manipulated(cube, false)
	cube:set_texture(metalcube_texture, true)
	cube:get_animation():load(metalcube_animation)
	cube:get_animation():set_state("0")
	cube:get_animation():set_playback(Playback.Loop)
	cube:sprite():set_layer(-2)
	cube:set_health(9999)
	cube:share_tile(false)
	cube:add_defense_rule(metal_defense_rule)
    mob:get_field():spawn(cube, x, y)
	return cube
end