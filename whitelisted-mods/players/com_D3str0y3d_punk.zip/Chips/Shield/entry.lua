local punkshield = {}

punkshield.init = function(user)
    user.punkshield_cooldown = 0
    user.punkshield_cooldown_component = Battle.Component.new(user, Lifetimes.Local)

    user.punkshield_cooldown_component.update_func = function()
        if user.punkshield_cooldown > 0 then 
            user.punkshield_cooldown = user.punkshield_cooldown - 1
        end
    end

    user:register_component(user.punkshield_cooldown_component)

    user.punkshield_initialized = true
end

punkshield.card_create_action = function(user,props)
    if not user.punkshield_initialized then 
        punkshield.init(user)
    end

    if user.punkshield_cooldown > 0 then 
        return
    end
    local action = Battle.CardAction.new(user, "PLAYER_GUARD")
	action:set_lockout(make_animation_lockout())
    local GUARDING = {1, 1.024}
    local POST_GUARD = {1, 0.224} 
	local FRAMES = make_frame_data({GUARDING,POST_GUARD})
    action.action_end_func = function()
        user.punkshield_cooldown = 130
        user:remove_defense_rule(action.guarding_defense_rule)
    end
    action:override_animation_frames(FRAMES)

    action.execute_func = function(self, user)
        local direction = user:get_facing()
        local field = user:get_field()
        local team = user:get_team()
        local usertile = user:get_current_tile()

        local guarding = false
        local shield_attachment = self:add_attachment("BUSTER")
        local shield_sprite = shield_attachment:sprite()
        shield_sprite:set_texture(user:get_texture())
        shield_sprite:set_layer(-2)

        local shield_animation = shield_attachment:get_animation()
        shield_animation:copy_from(user:get_animation())
        shield_animation:set_state("PROTOSHIELD")

        action.guarding_defense_rule = Battle.DefenseRule.new(0,DefenseOrder.Always)

		self:add_anim_action(1,function()
			guarding = true
            Engine.play_audio(Engine.load_audio(_folderpath.."shield.ogg"), AudioPriority.Highest)
		end)
		self:add_anim_action(2,function()
			shield_animation:set_state("FADE")
			guarding = false
            user:remove_defense_rule(action.guarding_defense_rule)
		end)

        action.guarding_defense_rule.can_block_func = function(judge, attacker, defender)
            if not guarding then 
                return 
            end
            local attacker_hit_props = attacker:copy_hit_props()
            if attacker_hit_props.damage > 0 then
                if attacker_hit_props.flags & Hit.Breaking == Hit.Breaking then
                    return
                end
                judge:block_impact()
                judge:block_damage()
                Engine.play_audio(Engine.load_audio(_folderpath.."hit.ogg"), AudioPriority.High)
                if not action.guarding_defense_rule.has_reflected then
                    local hitfx = Battle.Artifact.new()
                    hitfx:set_texture(Engine.load_texture(_folderpath.."hit.png"),true)
                    hitfx:set_facing(direction)
                    hitfx:set_offset(0,-30)
                    local fxanim = hitfx:get_animation()
                    local fxsprite = hitfx:sprite()
                    fxanim:load(_folderpath.."hit.animation")
                    fxanim:set_state("0")
                    fxanim:refresh(fxsprite)
                    fxanim:on_complete(function()
                        hitfx:delete()
                    end)
                    user:get_field():spawn(hitfx,user:get_current_tile())
                    action.guarding_defense_rule.has_reflected = true
                end
            end
        end
        user:add_defense_rule(action.guarding_defense_rule)
    end

    return action
end

return punkshield