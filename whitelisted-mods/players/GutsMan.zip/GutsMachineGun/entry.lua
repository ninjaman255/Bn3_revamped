local TEXTURE = Engine.load_texture(_folderpath.."battle_fx15_animations.png")
local HIT_SFX = Engine.load_audio(_modpath.."shared_resources/hit.ogg")
local PEW_SFX = Engine.load_audio(_folderpath.."pew.ogg")

function init(player)
    player.GMG_init = true

    player.GMG_pressed = 0
    -- I'm doing a totally fake buffer, which might make it "easier" to do, but might also fire when you don't want it. Tweak through testing, I guess
    player.GMG_buffer_time = 25
    player.GMG_remaining_buffer = player.GMG_buffer_time

    local comp = Battle.Component.new(player, Lifetimes.Battlestep)
    comp.update_func = function()
        local rem_buf = player.GMG_remaining_buffer
        if rem_buf == 0 then 
            player.GMG_pressed = player.GMG_pressed - 1
            if player.GMG_pressed < 0 then 
                player.GMG_pressed = 0
            end

            rem_buf = player.GMG_buffer_time+1
        end

        if player:input_has(Input.Pressed.Shoot) then 
            player.GMG_pressed = player.GMG_pressed + 1
        end

        if player.GMG_pressed > 0 then
            player.GMG_remaining_buffer = rem_buf - 1
        end
    end

    player:register_component(comp)
end

-- For some reason, can't math.random with negatives right now. I'm using a function like this for now. Come back and remove it later maybe, or add a range
-- If I keep it, add ranges and also round them off to be even (proper pixels)
function get_random_offset()
    local x = math.random(0, 40)
    local y = math.random(10, 20)
    
    x = x - 20
    y = y * -1

    return {x = x, y = y}
end

function card_create_action(player)
    if not player.GMG_init then 
        init(player)
    end
    
    if player.GMG_pressed >= 4 then 
        player.GMG_pressed = 0
        return guts_machine_gun(player)
    end

    local action = Battle.Buster.new(player, false, player:get_attack_level())
    local has_queued_next = false
    

    for i=1, 4
    do
        action:add_anim_action(i, function()
            if not has_queued_next then 
                if player.GMG_pressed >= 4 then 
                    local action = guts_machine_gun(player)
                    player:card_action_event(action, ActionOrder.Voluntary)

                    player.GMG_pressed = 0
                    has_queued_next = true
                end
            end
        end)
    end

    return action
end

function guts_machine_gun(player)
    local action = Battle.CardAction.new(player, "PLAYER_SHOOTING")
    local attachment = nil
    local attachment_anim = nil
    local attachment_sprite = nil
    local shots = 5

    local override_frames = {
        {1, 0.2}, -- 12f
    }

    local shoot_frames = {{2, 0.033}, {2, 0.016}, {3, 0.033}, {1, 0.0166}}
    
    for i=1, shots
    do
        for j=1, #shoot_frames
        do
            table.insert(override_frames, shoot_frames[j])
        end

        local frame_offset = #shoot_frames * (i-1)

        -- It's the first frame of shoot_frames
        for k=1, #shoot_frames
        do
            action:add_anim_action(k+1 + frame_offset, function()
                attachment_anim:set_playback_speed(1)
                local f = 1
                if k < 3 then 
                    f = 2
                elseif f > 3 then 
                    f = 3
                end
                skip_to_frame(attachment_sprite, attachment_anim, "BUSTER", f)
                attachment_anim:set_playback_speed(0)

            end)
        end
        

        -- It's the second frame of shoot_frames
        action:add_anim_action(3 + frame_offset, function()
            Engine.play_audio(PEW_SFX, AudioPriority.Low)
            local height = action:get_actor():sprite():get_height()
            height = height - action:get_actor():get_animation():point("buster").y
            height = height - attachment_anim:point("endpoint").y
            height = height - 6
            shoot_guts_machine_gun(player, height*-1, i == shots)
        end)
    end


    table.insert(override_frames, {1, 0.133})

    local frame_data = make_frame_data(override_frames)
    action:override_animation_frames(frame_data)

    action.execute_func = function(self)
        attachment = self:add_attachment("buster")
        attachment_anim = attachment:get_animation()
        attachment_sprite = attachment:sprite()
        attachment_anim:copy_from(player:get_animation())
        attachment_sprite:set_texture(player:get_texture())
        attachment_sprite:set_layer(-1)

        attachment_anim:set_state("BUSTER")
        attachment_anim:refresh(attachment_sprite)

        attachment_anim:set_playback_speed(0)
    end
    action.action_end_func = function()
        player.GMG_pressed = 0
        player.GMG_remaining_buffer = player.GMG_buffer_time
    end

    return action
end

function shoot_guts_machine_gun(player, height, is_last)
    height = height or -30

    local tile = player:get_tile(player:get_facing(), 1)
    if not tile then return end
    local field = player:get_field()

    local spell = graphic_init("spell", 0, height, TEXTURE, "battle_fx15_animations.animation", -3, "0", player, player:get_facing())

    local props = HitProps.new(
        4 * player:get_attack_level(),
        Hit.Impact | 2048,
        Element.None, 
        player:get_context(),
        Drag.None
    )

    if is_last then 
        props.flags = props.flags | Hit.Flinch | Hit.Flash
    end

    spell:set_hit_props(props)

    spell.tiles_moved = 0
    spell.update_func = function(self)
        local t = self:get_current_tile()
        t:attack_entities(self)
        t:highlight(Highlight.Solid)
        if t:is_edge() then 
            self:delete()
            return
        end

        if not self:is_moving() then 
            self.tiles_moved = self.tiles_moved + 1
            if self.tiles_moved > 2 then 
                self:delete()
                self:hide()
                return 
            end
            local dest = self:get_tile(self:get_facing(), 1)
            if dest then 
                self:slide(dest, frames(2), frames(0), ActionOrder.Voluntary, nil)
            end
        end
    end

    spell.can_move_to_func = function()
        return true
    end

    spell.collision_func = function(self)
        self:delete()
    end

    spell.attack_func = function(self, other)
        local o = get_random_offset()
        local hit_effect = graphic_init("artifact", o.x, o.y+height, TEXTURE, "battle_fx15_animations.animation", -3, "1", self, self:get_facing(), true)
        self:get_field():spawn(hit_effect, other:get_current_tile())
        Engine.play_audio(HIT_SFX, AudioPriority.Low)
    end

    field:spawn(spell, tile)
end

-- Do not use this function if you don't want to deal with consequences.
-- T(awful), will infinite loop if given out of range 'frame'
function skip_to_frame(sprite, anim, state, frame)
    anim:set_state(state)
    local reached = false
    if frame == 1 then reached = true end

    anim:on_frame(frame, function()
        reached = true
    end, true)

    while not reached 
    do
        anim:update(1/60, sprite)
    end

    anim:refresh(sprite)
end

function graphic_init(type, x, y, texture, animation, layer, state, user, facing, delete_on_complete, flip)
    flip = flip or false
    delete_on_complete = delete_on_complete or false
    facing = facing or nil
    
    local graphic = nil
    if type == "artifact" then 
        graphic = Battle.Artifact.new()

    elseif type == "spell" then 
        graphic = Battle.Spell.new(user:get_team())
    
    elseif type == "obstacle" then 
        graphic = Battle.Obstacle.new(user:get_team())

    end

    graphic:sprite():set_layer(layer)
    graphic:never_flip(flip)
    graphic:set_texture(texture, false)
    if facing then 
        graphic:set_facing(facing)
    end
    
    if user:get_facing() == Direction.Left then 
        x = x * -1
    end
    graphic:set_offset(x, y)
    local anim = graphic:get_animation()
    anim:load(_folderpath..animation)

    anim:set_state(state)
    anim:refresh(graphic:sprite())

    if delete_on_complete then 
        anim:on_complete(function()
            graphic:delete()
        end)
    end

    return graphic
end

return card_create_action