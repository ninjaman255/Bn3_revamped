local shared_package_init = include("../shared/entry.lua")

function package_init(character)
    local character_info = {
        name = "Rounda",
        hp = 60,
        damage = 20,
        palette = _folderpath.."V1.png",
        height = 44,
        frames_between_actions = 78,
        boomerang_speed = 7,
        move_speed = 70,
    }
    if character:get_rank() == Rank.SP then
        character_info.hp = 240
        character_info.damage = 100
        character_info.palette = _folderpath.."SP.png"
        character_info.boomerang_speed = 4
        character_info.move_speed = 40
    end
    shared_package_init(character, character_info)
end