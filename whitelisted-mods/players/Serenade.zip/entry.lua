function package_init(package) 
    package:declare_package_id("com.navi.PVP.Ota&D3str0y3d255&alrysc.Serenade")
    package:set_speed(1.0)
    package:set_attack(1)
    package:set_charged_attack(10)
    package:set_special_description("One sweet serenade")
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
    package:set_overworld_animation_path(_modpath.."ow.animation")
    package:set_overworld_texture_path(_modpath.."ow.png")
    package:set_mugshot_animation_path(_modpath.."mug.animation")
    package:set_mugshot_texture_path(_modpath.."mug.png")
end

function player_init(player)
    player:set_name("Serenade")
    player:set_health(1000)
    player:set_element(Element.None)
    player:set_height(76.0)
    player:set_charge_position(0,-26)

    local base_animation_path = _modpath.."battle.animation"
    local base_texture = Engine.load_texture(_modpath.."battle.png")

    player:set_animation(base_animation_path)
    player:set_texture(base_texture)
    player:set_fully_charged_color(Color.new(173, 216, 230, 255))

    player.normal_attack_func = function()
        return Battle.Buster.new(player, false, player:get_attack_level())
    end

    player.charged_attack_func = include("HolyShock/entry.lua")

    player.special_attack_func = include("shield/entry.lua").card_create_action
end