local noop = function () end
--local DankAura = include("DankAura/entry.lua")
local animation_path = _modpath.."targetdummy.animation"

local regen = false

local BARRIER_TEXTURE = Engine.load_texture(_folderpath.."barrier.png") 
local BARRIER_ANIMATION_PATH = _folderpath.."barrier.animation" 
local BARRIER_UP_SOUND = Engine.load_audio(_folderpath.."Barrier.ogg") -- Normalized -0.1

-- entry.lua

local idle_update
local healtimer = 0

idle_update = function(dummy, dt)
    --local y = canodumb:get_tile():y()
    local team = dummy:get_team()
    local field = dummy:get_field()
    if dummy:get_rank() == Rank.V2 then
          --while dummy:get_health() < 1000 do
          if dummy:get_health() < 1000 then
              healtimer = healtimer + 1
              --print("count") --remove afterwards
              if healtimer % 250 == 0 then
                  create_barrier(dummy)
                  --dummy:set_health(dummy:get_health() + 1000) --handles v2 variant life recovery
                  Engine.play_audio(AUDIO, AudioPriority.Low)
                  healtimer = 0
                  print("healed!")
              end
          end
        if dummy:get_health() >= 1000 then
            healtimer = 0
            --print ("timer reset")
            --end
        end
    end
end


function package_init(dummy)
    AUDIO = Engine.load_audio(_modpath.."sfx.ogg")

    -- private variables

    dummy._idle_state = "IDLE1"

    -- meta
    dummy:set_name("TrgtDmy")
    dummy:set_height(44)

    local rank = dummy:get_rank()

    if rank == Rank.V1 then
        dummy:set_health(1000)
        --regen = false
    elseif rank == Rank.V2 then
        dummy._idle_state = "IDLE2"
        --regen = true
        dummy:set_name("TrgtDmy")
        dummy:set_health(1000)
    else
        --safeguard
        dummy:set_health(200)
        --regen = false
    end

    dummy:set_element(Element.None)

    dummy:set_texture(Engine.load_texture(_folderpath.."targetdummy.png"))

    local anim = dummy:get_animation()
    anim:load(animation_path)
    anim:set_state(dummy._idle_state)
    --anim:set_playback(Playback.Once)

    -- setup defense rules
    --dummy.defense = Battle.DefenseVirusBody.new() -- lua owns this need to keep it alive
    --dummy:add_defense_rule(dummy.defense)
    local super_armor = Battle.DefenseRule.new(813, DefenseOrder.CollisionOnly)
	  super_armor.filter_statuses_func = function(statuses)
        if (statuses.flags & Hit.Stun == Hit.Stun) or (statuses.flags & Hit.Freeze == Hit.Freeze) then
        else
            --print("not flinching")
	  	      statuses.flags = statuses.flags & ~Hit.Flinch
	  	      statuses.flags = statuses.flags & ~Hit.Flash
        end
	  	  return statuses
	  end
	  dummy:add_defense_rule(super_armor)

    -- setup event hanlders
    dummy.update_func = idle_update
    dummy.battle_start_func = noop
    dummy.battle_end_func = noop
    dummy.on_spawn_func = noop
    --canodumb.delete_func = delete_func
end

function create_barrier(user)
  local offsetY = -2*(user:get_height()-48) -- MegaMan is 48 and I built around that, so I'm just offsetting for different heights by a bit
  print(offsetY)
  if offsetY > 0 then offsetY = 0 end
  local fading = false
  local isWind = false

  local remove_barrier = false

  local barrier = user:create_node()
  local HP = 420
  barrier:set_layer(3)
  barrier:set_texture(BARRIER_TEXTURE, true)
  local barrier_animation = Engine.Animation.new(BARRIER_ANIMATION_PATH)
  barrier_animation:set_state("BARRIER_IDLE")
  barrier_animation:refresh(barrier)
  if offsetY < 0 then
    barrier:set_offset(0, offsetY+(user:get_height()-barrier_animation:point("origin").y))
  end
  barrier_animation:set_playback(Playback.Loop)

  local number = user:create_node()
  number:set_texture(BARRIER_TEXTURE, true)
  --number:never_flip(true)
  local number_animation = Engine.Animation.new(BARRIER_ANIMATION_PATH)
  number_animation:load(BARRIER_ANIMATION_PATH)
  number_animation:set_state("NUMBER")
  number_animation:refresh(number)
  number:set_offset(0, 12)
  number_animation:set_playback(Playback.Loop)
  number:set_layer(-2)

  local barrier_defense_rule = Battle.DefenseRule.new(1, DefenseOrder.Always) -- Keristero's Guard is 0
  barrier_defense_rule.can_block_func = function(judge, attacker, defender)
      local attacker_hit_props = attacker:copy_hit_props()
  if attacker_hit_props.damage >= HP then
    HP = HP - attacker_hit_props.damage
  end
      judge:block_damage()
      if attacker_hit_props.element == Element.Wind then
          isWind = true
      end
  end

  local aura_animate_component = Battle.Component.new(user, Lifetimes.Scene)

  aura_animate_component.update_func = function(self, dt)
    barrier_animation:update(dt, barrier)
  end

  local aura_fade_countdown = 4200
  local aura_fade_component = Battle.Component.new(user, Lifetimes.Battlestep)
  aura_fade_component.update_func = function(self, dt)
    if aura_fade_countdown <= 0 then
      destroy_aura = true
    else
      aura_fade_countdown = aura_fade_countdown - 1
    end
  end

  local aura_destroy_component = Battle.Component.new(user, Lifetimes.Scene)
  local destroy_aura = false
  aura_destroy_component.update_func = function(self, dt)
  if isWind and not fading then 
          remove_barrier = true
      end
  
  if destroy_aura and not fading then
    remove_barrier = true
  end
  
      if HP <= 0 and not fading then
          remove_barrier = true
      end
      
      if barrier_defense_rule:is_replaced() then
          remove_barrier = true
      end
  
  if remove_barrier and not fading then
    user:sprite():remove_node(number)
    fading = true
    user:remove_defense_rule(barrier_defense_rule)
    
    barrier_animation:set_state("BARRIER_FADE")
    barrier_animation:refresh(barrier)
    barrier_animation:set_playback(Playback.Once)
    
    barrier_animation:on_complete(function()
      user:sprite():remove_node(barrier)
      aura_fade_component:eject()
      aura_animate_component:eject()
      aura_destroy_component:eject()
    end)

    if isWind then
      local initialX = barrier:get_offset().x
      local initialY = barrier:get_offset().y
      local facing_check = 1
      if user:get_facing() == Direction.Left then
        facing_check = -1
      end
      
      barrier_animation:on_frame(1, function() 
        barrier:set_offset(facing_check*(-25-initialX), -20+initialY)
      end)

      barrier_animation:on_frame(2, function() 
        barrier:set_offset(facing_check*(-50-initialX), -40+initialY)
      end)

      barrier_animation:on_frame(3, function() 
        barrier:set_offset(facing_check*(-75-initialX), -60+initialY)
      end)
    end
  end
end

  user:add_defense_rule(barrier_defense_rule)
user:register_component(aura_fade_component)
user:register_component(aura_destroy_component)
user:register_component(aura_animate_component)
end