local shared_package_init=include("enemy/yort.lua")

function package_init(character)
	local paletterank=0
	local virusrank=character:get_rank()
	if virusrank>=7 then paletterank=7 else paletterank=virusrank end
    local character_info={
        name="Yort",
        hp=120,
        damage=30,
        palette=_modpath.."enemy/palette"..paletterank..".png",
        height=44,
        frames_between_actions=30,
        move_speed=20,
    }
    if virusrank==1 then
        character_info.hp=140
        character_info.damage=40
        character_info.move_speed=18
    elseif virusrank==2 then
        character_info.hp=180
        character_info.damage=50
        character_info.move_speed=16
    elseif virusrank==3 then
        character_info.hp=220
        character_info.damage=60
        character_info.move_speed=14
    elseif virusrank==4 then
        character_info.hp=260
        character_info.damage=70
        character_info.move_speed=12
    elseif virusrank==5 then
        character_info.hp=300
        character_info.damage=80
        character_info.move_speed=10
    elseif virusrank==6 then
        character_info.hp=340
        character_info.damage=90
        character_info.move_speed=8
    elseif virusrank>=17 then
        character_info.hp=800
        character_info.damage=200
        character_info.move_speed=6
    elseif virusrank>=7 then
        character_info.hp=120+(40*virusrank)
        character_info.damage=30+(10*virusrank)
        character_info.move_speed=6
    end
    shared_package_init(character, character_info)
	character.on_spawn_func=function()
		if virusrank==1 then
			character:set_name("Yurt")
		elseif virusrank==2 then
			character:set_name("Yart")
		elseif virusrank==3 then
			character:set_name("YortO")
		elseif virusrank==4 then
			character:set_name("YurtO")
		elseif virusrank==5 then
			character:set_name("YartO")
		elseif virusrank==6 then
			character:set_name("RareYort")
		elseif virusrank==7 then
			character:set_name("Yeet")
		elseif virusrank>=17 then
			character:set_name("YeetX")
		elseif virusrank>=8 then
			character:set_name("Yeet"..(virusrank-6))
		end
	end
end
