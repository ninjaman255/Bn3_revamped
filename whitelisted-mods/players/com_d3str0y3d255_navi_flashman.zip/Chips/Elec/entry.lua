local HIT_TEXTURE = Engine.load_texture(_folderpath .. "effect.png")
local HIT_ANIM = _folderpath .. "effect.animation"

local flashelec = {}

flashelec.card_create_action = function(actor, props)
    local action = Battle.CardAction.new(actor, "PLAYER_CS")
    action:set_lockout(make_sequence_lockout())

    action.execute_func = function(self, user)
        local actor = self:get_actor()
        local team = user:get_team()
        local field = user:get_field()
        local step1 = Battle.Step.new()

        self.tile = user:get_current_tile()

        local ref = self

        local do_spawn = true

        step1.update_func = function(self, dt)
        
		local anim = user:get_animation()   
  if do_spawn then
                do_spawn = false      
                    anim:on_frame(6, function()
                        ref.flashelec = create_whip(user, props)
                    end)
                    anim:on_frame(7, function()
                        ref.flashelec.shock_ready = true
                        Engine.play_audio(AudioType.Thunder, AudioPriority.High)
                    end)
                    anim:on_complete(function()
                    step1:complete_step()
                    end)  
end					
        end
        self:add_step(step1)
    end
    action.action_end_func = function(self)

    end
    return action
end



function create_whip(user, props)
    local spell = Battle.Spell.new(user:get_team())
    local tile = user:get_tile(user:get_facing(), 1)
    local field = user:get_field()
    local spell_animation = spell:get_animation()
    spell:set_facing(user:get_facing())
    spell:set_hit_props(
        HitProps.new(
            props.damage,
            Hit.Impact | Hit.Flinch | Hit.Pierce | Hit.Retangible,
            Element.Elec,
            user:get_id(),
            Drag.None
        )
    )
    spell:set_facing(user:get_facing())
    spell_animation:copy_from(user:get_animation())
    spell_animation:set_state("ELEC")
    spell:set_texture(user:get_texture())
    spell:sprite():set_layer(-5)
    spell_animation:refresh(spell:sprite())

    spell_animation:on_complete(function()
        spell:erase()
    end)

    user:get_field():spawn(spell, tile)
    local hitbox1 = spawn_whip_hitbox(field, spell, tile:get_tile(user:get_facing(), 0))
    local hitbox2 = spawn_whip_hitbox(field, spell, tile:get_tile(user:get_facing(), 1))
    local hitbox3 = spawn_whip_hitbox(field, spell, tile:get_tile(user:get_facing(), 0):get_tile(Direction.Up, 1))
    local hitbox4 = spawn_whip_hitbox(field, spell, tile:get_tile(user:get_facing(), 0):get_tile(Direction.Down, 1))


    spell.update_func = function()
	
	if user:get_animation():get_state() ~= "PLAYER_CS" then
	spell:erase()
	end
	
        if (spell.shock_ready) then
            spell:get_current_tile():attack_entities(spell)
            hitbox1:get_current_tile():attack_entities(hitbox1)
            hitbox2:get_current_tile():attack_entities(hitbox2)
            hitbox3:get_current_tile():attack_entities(hitbox3)
            hitbox4:get_current_tile():attack_entities(hitbox4)			
        end
    end


    local judge_hit = function(self)
        create_basic_effect(user:get_field(), self:get_current_tile(), HIT_TEXTURE, HIT_ANIM, "ELEC")
        Engine.play_audio(Engine.load_audio(_folderpath .. "hitsound.ogg"), AudioPriority.High)
    end

    spell.attack_func = judge_hit
    hitbox1.attack_func = judge_hit
    hitbox2.attack_func = judge_hit
    hitbox3.attack_func = judge_hit
    hitbox4.attack_func = judge_hit	
    return spell
end

function spawn_whip_hitbox(field, spell, desired_tile)
    local hitbox = Battle.Spell.new(spell:get_team())
    hitbox:set_hit_props(spell:copy_hit_props())
    field:spawn(hitbox, desired_tile)
    return hitbox
end

function create_basic_effect(field, tile, hit_texture, hit_anim_path, hit_anim_state)
    local fx = Battle.Artifact.new()
    fx:set_texture(hit_texture, true)
    local fx_sprite = fx:sprite()
    fx_sprite:set_layer(-3)
    local fx_anim = fx:get_animation()
    fx_anim:load(hit_anim_path)
    fx_anim:set_state(hit_anim_state)
    fx_anim:refresh(fx_sprite)
    fx_anim:on_complete(function()
        fx:erase()
    end)
    field:spawn(fx, tile)
    return fx
end

return flashelec