function package_init(package) 
    package:declare_package_id("com.claris.card.Sword02")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'H', 'L', 'S', '*'})

    local props = package:get_card_props()
    props.shortname = "WideSwrd"
    props.damage = 80
    props.time_freeze = false
    props.element = Element.Sword
    props.description = "Cuts enmy in front! Range: 3"
	props.limit = 5
end

local basic_flame = {}

basic_flame.card_create_action = function(user, props)
    local action = Battle.CardAction.new(user, "PLAYER_CS")
	action:set_lockout(make_animation_lockout())
	local sword = create_slash(user, props)	
    action.execute_func = function(self, user)
		local field = user:get_field()
		
		self:add_anim_action(2, function()
			    Engine.play_audio(Engine.load_audio(_folderpath.."sfx.ogg"), AudioPriority.High)
		end)					
		
		self:add_anim_action(3, function()
			local tile = user:get_tile(user:get_facing(), 1)
			field:spawn(sword, tile)
		end)	

		self:add_anim_action(11, function()
    if not sword:is_deleted() then sword:delete()end	
		end)	
    end

    action.action_end_func = function(self)
    if not sword:is_deleted() then sword:delete()end	
    end	
	
    return action
end

function create_slash(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			Element.Fire,
			user:get_context(),
			Drag.None
		)
	)	
	local attack_once = true
	local field = user:get_field()
    spell.update_func = function(self, dt) 
		local tile = spell:get_current_tile()
		tile:attack_entities(self)			
	end

    spell.delete_func = function(self)
		self:erase()
    end

	spell.can_move_to_func = function(tile)
		return false
	end
	
    spell.collision_func = function(self, other)
        self.has_hit = true
        local fx1 = Battle.Artifact.new()
        fx1:set_offset( 0, -25 )
	    Engine.play_audio(Engine.load_audio(_folderpath.."hitsound.ogg"), AudioPriority.High)
        local explosion_texture = Engine.load_texture(_folderpath .. "spell_bullet_hit.png")
        fx1:set_texture(explosion_texture)
        local fx1_anim = fx1:get_animation()
        fx1_anim:load(_folderpath .. "spell_bullet_hit.animation")
        fx1_anim:set_state("FIRE")
        fx1_anim:refresh(fx1:sprite())
        fx1:sprite():set_layer(-2)
        fx1_anim:on_complete(function()
            fx1:erase()
        end)
        self:get_field():spawn(fx1, self:get_tile())
		self:delete()
		end
	
	return spell
end

return basic_flame