function package_init(package) 
    package:declare_package_id("com.claris.card.Sword02")
    package:set_icon_texture(Engine.load_texture(_modpath.."icon.png"))
    package:set_preview_texture(Engine.load_texture(_modpath.."preview.png"))
	package:set_codes({'H', 'L', 'S', '*'})

    local props = package:get_card_props()
    props.shortname = "WideSwrd"
    props.damage = 80
    props.time_freeze = false
    props.element = Element.Sword
    props.description = "Cuts enmy in front! Range: 3"
	props.limit = 5
end

local slash2 = {}

slash2.card_create_action = function(actor, props)
    local action = Battle.CardAction.new(actor, "SLASH2")
	action:set_lockout(make_animation_lockout())
	local SLASH_TEXTURE = Engine.load_texture(_folderpath.."spell_sword_slashes.png")
    action.execute_func = function(self, user)
		self:add_anim_action(2, function()

		end)
		
		local field = user:get_field()
		self:add_anim_action(3, function()
			local sword = create_slash(user, props)
			local tile = user:get_tile(user:get_facing(), 1)
			local fx = Battle.Artifact.new()
			fx:set_facing(sword:get_facing())
			local anim = fx:get_animation()
			fx:set_texture(SLASH_TEXTURE, true)
			anim:load(_folderpath.."spell_sword_slashes.animation")
			anim:set_state("WIDE")
			anim:on_complete(function()
				fx:erase()
				if not sword:is_deleted() then sword:delete() end
			end)
			field:spawn(sword, tile)
			field:spawn(fx, tile)
		end)
	end
    return action
end

function create_slash(user, props)
	local spell = Battle.Spell.new(user:get_team())
	spell:set_facing(user:get_facing())
	spell:set_hit_props(
		HitProps.new(
			props.damage,
			Hit.Impact | Hit.Flinch | Hit.Flash,
			Element.Sword,
			user:get_context(),
			Drag.None
		)
	)
	local attack_once = true
	local field = user:get_field()
    spell.update_func = function(self, dt) 
		local tile = spell:get_current_tile()
		local tile_next = tile:get_tile(Direction.Up, 1)
		local tile_next_two = tile:get_tile(Direction.Down, 1)
		if tile_next and not tile_next:is_edge() then
		end
		if attack_once then
			if tile_next and not tile_next:is_edge() then
				local hitbox_r = Battle.SharedHitbox.new(self, 0.2)
				hitbox_r:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_r, tile_next)
			end
			if tile_next_two and not tile_next_two:is_edge() then
				local hitbox_l = Battle.SharedHitbox.new(self, 0.2)
				hitbox_l:set_hit_props(self:copy_hit_props())
				field:spawn(hitbox_l, tile_next_two)
			end
			attack_once = false
		end
		tile:attack_entities(self)
	end

	spell.can_move_to_func = function(tile)
		return true
	end
	local AUDIO = Engine.load_audio(_folderpath.."sfx.ogg")
	Engine.play_audio(AUDIO, AudioPriority.Low)

	return spell
end

return slash2